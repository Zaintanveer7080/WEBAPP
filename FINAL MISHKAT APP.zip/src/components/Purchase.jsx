
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Edit, Trash2, ShoppingCart, FileDown, Eye } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import PurchaseForm from '@/components/purchase/PurchaseForm';
import FormPanel from '@/components/FormPanel';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { generatePdf } from '@/components/pdf/PdfGenerator';
import PurchaseInvoiceTemplate from '@/components/pdf/PurchaseInvoiceTemplate';

const PaymentStatusBadge = ({ status }) => {
  const statusStyles = {
    Paid: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    Partial: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    Credit: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
  };
  return (
    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${statusStyles[status] || ''}`}>
      {status}
    </span>
  );
};

function Purchase() {
  const { data, updateData, requestPasscode, setTransactionToView, getInvoiceStatus } = useData();
  const { purchases, suppliers, items, sales, payments } = data;
  const { toast } = useToast();

  const [view, setView] = useState('list');
  const [editingPurchase, setEditingPurchase] = useState(null);

  const handleDownloadPdf = (purchase) => {
    const supplier = suppliers.find(s => s.id === purchase.supplierId);
    generatePdf(
      <PurchaseInvoiceTemplate purchase={purchase} supplier={supplier} items={items} settings={data.settings} getInvoiceStatus={getInvoiceStatus} />,
      `Purchase-Invoice-${purchase.purchaseNumber}.pdf`
    );
  };

  const handleDelete = (id) => {
    requestPasscode(() => {
        const purchaseToDelete = purchases.find(p => p.id === id);
        if(!purchaseToDelete) return;
        
        const isAnyItemUsedInSale = (purchaseToDelete.items || []).some(purchaseItem => 
            (sales || []).some(sale => (sale.items || []).some(saleItem => saleItem.itemId === purchaseItem.itemId))
        );

        if(isAnyItemUsedInSale) {
            toast({ title: "Deletion Failed", description: "Cannot delete. One or more items from this purchase have been sold.", variant: "destructive" });
            return;
        }

        const updatedPurchases = purchases.filter(p => p.id !== id);
        const updatedPayments = payments.filter(p => p.invoiceId !== id);
        updateData({ purchases: updatedPurchases, payments: updatedPayments });
        toast({ title: "Success", description: "Purchase and associated payments deleted successfully!" });
    });
  };

  const handleEdit = (purchase) => {
     requestPasscode(() => {
        setEditingPurchase(purchase);
        setView('form');
    });
  };
  
  const handleAddNew = () => {
    setEditingPurchase(null);
    setView('form');
  }

  const handleCloseForm = () => {
    setView('list');
    setEditingPurchase(null);
  }

  const getSupplierName = (supplierId) => (suppliers || []).find(s => s.id === supplierId)?.name || 'Unknown';

  const purchaseList = useMemo(() => {
    return (purchases || []).map(p => ({
        ...p,
        supplierName: getSupplierName(p.supplierId),
        statusInfo: getInvoiceStatus(p)
    })).reverse();
  }, [purchases, suppliers, getInvoiceStatus]);

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Purchase Management</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Create and manage your purchase invoices.</p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="h-4 w-4 mr-2" />
          New Purchase
        </Button>
      </div>

      <AnimatePresence mode="wait">
        {view === 'list' && (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ShoppingCart className="h-5 w-5 mr-2" />
                  Purchase History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {purchaseList.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingCart className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500">No purchases found. Create your first purchase!</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Inv #</th>
                          <th className="text-left p-2">Date</th>
                          <th className="text-left p-2">Supplier</th>
                          <th className="text-right p-2">Total Bill</th>
                          <th className="text-right p-2">Paid Amount</th>
                          <th className="text-center p-2">Status</th>
                          <th className="text-center p-2">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {purchaseList.map((purchase, index) => (
                          <motion.tr
                            key={purchase.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.05 }}
                            className="border-b hover:bg-muted"
                          >
                            <td className="p-2 font-mono">{purchase.purchaseNumber}</td>
                            <td className="p-2">{new Date(purchase.date).toLocaleDateString()}</td>
                            <td className="p-2">{purchase.supplierName}</td>
                            <td className="p-2 font-semibold text-right text-blue-600">RS {purchase.totalCost.toFixed(2)}</td>
                            <td className="p-2 font-semibold text-right text-green-600">RS {purchase.paidAmount.toFixed(2)}</td>
                            <td className="p-2 text-center"><PaymentStatusBadge status={purchase.statusInfo.status} /></td>
                            <td className="p-2">
                              <div className="flex justify-center space-x-1">
                                <Button size="icon" variant="ghost" onClick={() => setTransactionToView({ transaction: purchase, type: 'purchase' })}><Eye className="h-4 w-4 text-purple-500" /></Button>
                                <Button size="icon" variant="ghost" onClick={() => handleEdit(purchase)}><Edit className="h-4 w-4" /></Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button size="icon" variant="ghost"><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will delete the purchase invoice and all associated payments. This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDelete(purchase.id)}>Delete</AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                                <Button size="icon" variant="ghost" onClick={() => handleDownloadPdf(purchase)}>
                                  <FileDown className="h-4 w-4 text-blue-500" />
                                </Button>
                              </div>
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {view === 'form' && (
          <FormPanel
            key="form"
            title={editingPurchase ? 'Edit Purchase Invoice' : 'New Purchase Invoice'}
            onClose={handleCloseForm}
          >
            <PurchaseForm
              purchase={editingPurchase}
              onClose={handleCloseForm}
            />
          </FormPanel>
        )}
      </AnimatePresence>
    </div>
  );
}

export { Purchase };
