
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Trash2, Plus, AlertTriangle, Truck, TrendingUp, TrendingDown } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const SalesForm = ({ sale, onClose }) => {
  const { data, updateData } = useData();
  const { customers, items, banks, cashInHand, sales, purchases, onlineOrders, payments } = data;
  const { toast } = useToast();

  const [saleNumber, setSaleNumber] = useState('');
  const [customerId, setCustomerId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [saleItems, setSaleItems] = useState([]);
  const [notes, setNotes] = useState('');

  const [discount, setDiscount] = useState('');
  const [discountType, setDiscountType] = useState('flat');
  
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paidAmount, setPaidAmount] = useState('');
  const [bankId, setBankId] = useState('');
  const [paymentRef, setPaymentRef] = useState('');
  const [isOnlineOrder, setIsOnlineOrder] = useState(false);

  const generateSaleNumber = () => {
    const validSales = (sales || [])
      .filter(s => s && s.saleNumber && typeof s.saleNumber === 'string' && s.saleNumber.startsWith('S-'))
      .map(s => parseInt(s.saleNumber.split('-')[1] || '0', 10))
      .sort((a, b) => a - b);
      
    if (validSales.length === 0) return 'S-0001';
    const lastNum = validSales[validSales.length - 1];
    return `S-${(lastNum + 1).toString().padStart(4, '0')}`;
  };

  const getItemStock = (itemId) => {
    if (!itemId) return 0;
    const itemData = (items || []).find(i => i.id === itemId);
    const openingStock = itemData?.openingStock || 0;
    const totalPurchased = (purchases || []).reduce((sum, p) => sum + ((p?.items || []).find(pi => pi.itemId === itemId)?.quantity || 0), 0);
    const totalSold = (sales || []).reduce((sum, s) => {
      if (sale && s.id === sale.id) return sum;
      return sum + ((s?.items || []).find(si => si.itemId === itemId)?.quantity || 0);
    }, 0);
    return openingStock + totalPurchased - totalSold;
  };
  
  const getPurchaseCostForItem = useCallback((itemId) => {
    const allPurchasesForItem = (purchases || [])
      .flatMap(p => (p.items || []).map(item => ({ ...item, date: p.date })))
      .filter(item => item.itemId === itemId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    if (allPurchasesForItem.length > 0) {
      return allPurchasesForItem[0].price;
    }
    
    const itemMaster = (items || []).find(i => i.id === itemId);
    return itemMaster?.purchasePrice || 0;
  }, [purchases, items]);

  const calculateTotals = useCallback(() => {
    const currentSaleItems = Array.isArray(saleItems) ? saleItems : [];
    const subTotal = currentSaleItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.price || 0)), 0);
    const enteredDiscount = parseFloat(discount) || 0;
    let totalDiscount = discountType === 'flat' ? enteredDiscount : subTotal * (enteredDiscount / 100);
    if(isNaN(totalDiscount)) totalDiscount = 0;

    const totalCost = subTotal - totalDiscount;
    const totalQuantity = currentSaleItems.reduce((sum, item) => sum + (parseInt(item.quantity) || 0), 0);
    const balance = totalCost - (parseFloat(paidAmount) || 0);

    const itemsCost = currentSaleItems.reduce((cost, saleItem) => {
      const purchasePrice = getPurchaseCostForItem(saleItem.itemId);
      return cost + (purchasePrice * (saleItem.quantity || 0));
    }, 0);
    
    const profit = totalCost - itemsCost;

    const firstItem = currentSaleItems.length > 0 ? (items || []).find(i => i.id === currentSaleItems[0].itemId) : null;
    const unit = firstItem ? firstItem.unit : '';

    return { subTotal, totalDiscount, totalCost, totalQuantity, balance, unit, profit };
  }, [saleItems, discount, discountType, paidAmount, items, getPurchaseCostForItem]);

  const { subTotal, totalDiscount, totalCost, totalQuantity, balance, unit, profit } = useMemo(() => calculateTotals(), [calculateTotals]);

  useEffect(() => {
    if (sale) {
      setSaleNumber(sale.saleNumber);
      setCustomerId(sale.customerId);
      setDate(sale.date);
      setSaleItems(sale.items || []);
      setNotes(sale.notes || '');
      setDiscount(sale.discount?.value || '');
      setDiscountType(sale.discount?.type || 'flat');
      setPaymentMethod(sale.payment?.method || 'cash');
      setPaidAmount(sale.paidAmount?.toString() || '');
      setBankId(sale.payment?.bankId || '');
      setPaymentRef(sale.payment?.ref || '');
      setIsOnlineOrder(!!sale.isOnlineOrder);
    } else {
      setSaleNumber(generateSaleNumber());
      setDate(new Date().toISOString().split('T')[0]);
      setSaleItems([{ itemId: '', quantity: 1, price: 0 }]);
      setIsOnlineOrder(false);
      setPaidAmount('');
    }
  }, [sale]);

  useEffect(() => {
    if (!sale) {
      setPaidAmount(totalCost.toFixed(2));
    }
  }, [totalCost, sale]);

  const handleItemChange = (index, field, value) => {
    const updatedItems = [...saleItems];
    updatedItems[index][field] = value;
    if (field === 'itemId') {
      const selectedItem = (items || []).find(i => i.id === value);
      if (selectedItem) {
        updatedItems[index]['price'] = selectedItem.salePrice || 0;
      }
    }
    setSaleItems(updatedItems);
  };

  const addItem = () => setSaleItems([...saleItems, { itemId: '', quantity: 1, price: 0 }]);
  const removeItem = (index) => setSaleItems(saleItems.filter((_, i) => i !== index));

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!customerId || saleItems.some(i => !i.itemId)) {
      toast({ title: 'Error', description: 'Customer and all items must be selected.', variant: 'destructive' });
      return;
    }
    if ((sales || []).some(s => s.saleNumber === saleNumber && s.id !== sale?.id)) {
      toast({ title: 'Error', description: 'Sale number must be unique.', variant: 'destructive' });
      return;
    }
    const isAnyItemOutOfStock = saleItems.some(i => i.itemId && (parseInt(i.quantity) || 0) > getItemStock(i.itemId));
    if (isAnyItemOutOfStock) {
        toast({ title: 'Error', description: 'Cannot complete sale. One or more items are out of stock for the selected quantity.', variant: 'destructive' });
        return;
    }

    const enteredPaidAmount = parseFloat(paidAmount) || 0;
    
    const saleId = sale ? sale.id : Date.now().toString();

    const saleData = {
      id: saleId,
      saleNumber, customerId, date, notes, isOnlineOrder,
      items: saleItems.map(i => ({...i, quantity: parseInt(i.quantity) || 0, price: parseFloat(i.price) || 0})),
      subTotal, totalQuantity, 
      totalCost: totalCost,
      discount: { value: parseFloat(discount) || 0, type: discountType },
      paidAmount: enteredPaidAmount,
      payment: { method: paymentMethod, bankId, ref: paymentRef }
    };
    
    const newPayments = [];
    const oldPaymentAmount = sale?.paidAmount || 0;

    if (enteredPaidAmount > 0) {
      newPayments.push({
        id: sale ? ((payments || []).find(p => p.invoiceId === sale.id)?.id || Date.now().toString() + Math.random()) : Date.now().toString() + Math.random(),
        partyId: customerId,
        partyType: 'customer',
        type: 'in',
        invoiceId: saleId,
        amount: enteredPaidAmount,
        date: date,
        method: paymentMethod,
        bankId: paymentMethod === 'bank' ? bankId : undefined,
        notes: `Payment for Sale #${saleNumber}`
      });
    }

    let updatedCashInHand = cashInHand;
    let updatedBanks = JSON.parse(JSON.stringify(banks || []));

    const cashDifference = (paymentMethod === 'cash' ? enteredPaidAmount : 0) - (sale?.payment.method === 'cash' ? oldPaymentAmount : 0);
    updatedCashInHand += cashDifference;

    if (sale?.payment.method === 'bank') {
        const oldBankIndex = updatedBanks.findIndex(b => b.id === sale.payment.bankId);
        if(oldBankIndex > -1) updatedBanks[oldBankIndex].balance -= oldPaymentAmount;
    }
    if (paymentMethod === 'bank') {
        const newBankIndex = updatedBanks.findIndex(b => b.id === bankId);
        if(newBankIndex > -1) updatedBanks[newBankIndex].balance += enteredPaidAmount;
    }

    const otherPayments = (payments || []).filter(p => p.invoiceId !== saleId);
    const updatedPayments = [...otherPayments, ...newPayments];
    const newSales = sale ? (sales || []).map(s => s.id === sale.id ? saleData : s) : [...(sales || []), saleData];
    
    let updatedOnlineOrders = [...(data.onlineOrders || [])];
    if(isOnlineOrder) {
        const existingOrderIndex = updatedOnlineOrders.findIndex(o => o.saleId === saleId);
        if (existingOrderIndex === -1) {
            const newOnlineOrder = {
                id: Date.now().toString(),
                saleId,
                status: 'Pending',
                statusHistory: [{ status: 'Pending', date: new Date().toISOString() }],
            };
            updatedOnlineOrders.push(newOnlineOrder);
            toast({ title: 'Online Order Created', description: 'This sale has been added to online orders for tracking.' });
        }
    } else {
        updatedOnlineOrders = updatedOnlineOrders.filter(o => o.saleId !== saleId);
    }

    updateData({ sales: newSales, onlineOrders: updatedOnlineOrders, banks: updatedBanks, cashInHand: updatedCashInHand, payments: updatedPayments });
    toast({ title: 'Success', description: `Sale ${sale ? 'updated' : 'saved'}.` });
    onClose();
  };

  return (
    <div className="flex flex-col h-full">
      <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div><Label htmlFor="saleNumber">Sale Number</Label><Input id="saleNumber" value={saleNumber} onChange={e => setSaleNumber(e.target.value)} /></div>
              <div><Label htmlFor="customer">Customer</Label><Select value={customerId} onValueChange={setCustomerId}><SelectTrigger><SelectValue placeholder="Select customer" /></SelectTrigger><SelectContent>{(customers || []).map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent></Select></div>
              <div><Label htmlFor="date">Date</Label><Input id="date" type="date" value={date} onChange={e => setDate(e.target.value)} /></div>
          </div>
          
          <div className="space-y-2 border-t border-b py-4">
              <Label>Items</Label>
              {saleItems.map((item, index) => (
              <div key={index} className="flex items-end gap-2">
                  <div className="flex-grow">
                  <Select value={item.itemId} onValueChange={v => handleItemChange(index, 'itemId', v)}>
                      <SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger>
                      <SelectContent>{(items || []).map(i => <SelectItem key={i.id} value={i.id} disabled={getItemStock(i.id) <= 0 && (!sale || !sale.items.find(si => si.itemId === i.id))}>{i.name} (Stock: {getItemStock(i.id)} {i.unit})</SelectItem>)}</SelectContent>
                  </Select>
                  </div>
                  <div className="w-24"><Input type="number" placeholder="Qty" value={item.quantity} onChange={e => handleItemChange(index, 'quantity', e.target.value)} min="1" /></div>
                  <div className="w-32"><Input type="number" placeholder="Price" value={item.price} onChange={e => handleItemChange(index, 'price', e.target.value)} /></div>
                  <div><Button type="button" variant="destructive" size="icon" onClick={() => removeItem(index)}><Trash2 className="h-4 w-4" /></Button></div>
              </div>
              ))}
              {saleItems.some(i => i.itemId && (parseInt(i.quantity) || 0) > getItemStock(i.itemId)) &&
                  <div className="text-red-600 text-sm flex items-center gap-2"><AlertTriangle className="h-4 w-4" /> Not enough stock for one or more items.</div>}
              <Button type="button" variant="outline" onClick={addItem} className="mt-2"><Plus className="h-4 w-4 mr-2"/>Add Item</Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
              <div>
                  <Label>Payment</Label>
                  <div className="grid grid-cols-2 gap-2">
                      <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                          <SelectTrigger><SelectValue/></SelectTrigger>
                          <SelectContent><SelectItem value="cash">Cash</SelectItem><SelectItem value="bank">Bank</SelectItem></SelectContent>
                      </Select>
                      {paymentMethod === 'bank' && <Select value={bankId} onValueChange={setBankId}><SelectTrigger><SelectValue placeholder="Select bank"/></SelectTrigger><SelectContent>{(banks || []).map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent></Select>}
                  </div>
                  {paymentMethod === 'bank' && <Input className="mt-2" placeholder="Bank Reference No." value={paymentRef} onChange={e => setPaymentRef(e.target.value)} />}
                  <div className="mt-2"><Label htmlFor="paidAmount">Paid Amount</Label><Input id="paidAmount" type="number" value={paidAmount} onChange={e => setPaidAmount(e.target.value)} /></div>
              </div>
              <div><Label htmlFor="notes">Notes</Label><Textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} /></div>
              <div className="flex items-center space-x-2">
                  <Switch id="online-order" checked={isOnlineOrder} onCheckedChange={setIsOnlineOrder}/>
                  <Label htmlFor="online-order" className="flex items-center gap-2"><Truck className="h-4 w-4"/> Is this an Online Order?</Label>
              </div>
              </div>
              <div className="bg-muted p-4 rounded-lg space-y-2">
                  <div className="flex justify-between items-center text-sm"><span>Total Quantity</span><span>{totalQuantity} {unit}</span></div>
                  <div className="flex justify-between items-center text-sm"><span>Subtotal</span><span>RS {subTotal.toFixed(2)}</span></div>
                  <div className="flex justify-between items-center"><span className="text-sm">Discount</span>
                  <div className="flex gap-1"><Input type="number" value={discount} onChange={e => setDiscount(e.target.value)} className="h-8 w-20"/><Select value={discountType} onValueChange={setDiscountType}><SelectTrigger className="h-8 w-24"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="flat">Flat</SelectItem><SelectItem value="percent">%</SelectItem></SelectContent></Select></div>
                  </div>
                  <div className="flex justify-between items-center font-bold text-lg border-t pt-2"><span>Total</span><span>RS {totalCost.toFixed(2)}</span></div>
                  <div className="flex justify-between items-center text-sm"><span>Paid</span><span>RS {(parseFloat(paidAmount) || 0).toFixed(2)}</span></div>
                  <div className="flex justify-between items-center text-sm font-semibold"><span>Balance</span><span>RS {balance.toFixed(2)}</span></div>
                  <div className={`flex justify-between items-center text-sm font-bold pt-2 mt-2 border-t ${profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      <span>Profit</span>
                      <span className="flex items-center gap-1">
                        {profit >= 0 ? <TrendingUp className="h-4 w-4"/> : <TrendingDown className="h-4 w-4"/>}
                        RS {profit.toFixed(2)}
                      </span>
                  </div>
              </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 p-4 border-t bg-background sticky bottom-0">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit">{sale ? 'Update' : 'Save'} Sale</Button>
        </div>
      </form>
    </div>
  );
};

export default SalesForm;
