import React from 'react';
import { motion } from 'framer-motion';
import { useData } from '@/contexts/DataContext';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  TrendingUp, 
  Package, 
  Users, 
  Building, 
  CreditCard,
  BarChart3,
  ArrowLeftRight,
  Wallet,
  Settings,
  Globe,
  LogOut
} from 'lucide-react';

const navItems = [
  { id: 'dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  { id: 'sales', icon: TrendingUp, label: 'Sales' },
  { id: 'purchase', icon: ShoppingCart, label: 'Purchases' },
  { id: 'onlineOrders', icon: Globe, label: 'Online Orders' },
  { id: 'items', icon: Package, label: 'Items' },
  { id: 'customers', icon: Users, label: 'Customers' },
  { id: 'suppliers', icon: Building, label: 'Suppliers' },
  { id: 'expenses', icon: CreditCard, label: 'Expenses' },
  { id: 'payments', icon: ArrowLeftRight, label: 'Payments' },
  { id: 'cashAndBank', icon: Wallet, label: 'Cash & Bank' },
  { id: 'reports', icon: BarChart3, label: 'Reports' },
  { id: 'settings', icon: Settings, label: 'Settings' }
];

const Sidebar = ({ activeModule, setActiveModule }) => {
  const { data } = useData();
  const { signOut } = useAuth();
  const companyName = data?.settings?.companyName || "ERP Pro";

  const handleLogout = async () => {
    await signOut();
  };

  return (
    <aside className="w-64 bg-gray-900 text-gray-300 flex flex-col sidebar-gradient">
      <div className="p-4 border-b border-gray-700">
        <h1 className="text-xl font-bold text-white text-center">{companyName}</h1>
      </div>
      <nav className="flex-1 p-2 space-y-1 overflow-y-auto">
        {navItems.map(item => (
          <motion.div
            key={item.id}
            whileHover={{ scale: 1.02, x: 5 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                setActiveModule(item.id);
              }}
              className={`flex items-center px-3 py-2.5 rounded-lg transition-colors duration-200
                ${activeModule === item.id 
                  ? 'bg-blue-600 text-white shadow-lg' 
                  : 'hover:bg-gray-700 hover:text-white'
                }`
              }
            >
              <item.icon className="w-5 h-5 mr-3" />
              <span className="font-medium">{item.label}</span>
            </a>
          </motion.div>
        ))}
      </nav>
      <div className="p-2 border-t border-gray-700">
        <motion.div
            whileHover={{ scale: 1.02, x: 5 }}
            whileTap={{ scale: 0.98 }}
            transition={{ type: "spring", stiffness: 400, damping: 17 }}
          >
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                handleLogout();
              }}
              className="flex items-center px-3 py-2.5 rounded-lg transition-colors duration-200 text-red-400 hover:bg-red-800/50 hover:text-red-200"
            >
              <LogOut className="w-5 h-5 mr-3" />
              <span className="font-medium">Logout</span>
            </a>
          </motion.div>
      </div>
      <div className="p-4 border-t border-gray-700 text-center text-xs">
        &copy; {new Date().getFullYear()} {companyName}
      </div>
    </aside>
  );
};

export default Sidebar;