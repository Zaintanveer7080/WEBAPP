import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  DollarSign, 
  TrendingUp, 
  Package, 
  CreditCard,
  Calendar,
  Download
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar } from 'recharts';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import { useToast } from '@/components/ui/use-toast';
import { useData } from '@/contexts/DataContext';

const COLORS = ['#667eea', '#764ba2', '#f093fb', '#f5576c', '#4facfe', '#00f2fe'];

function Dashboard() {
  const { data } = useData();
  const { sales, expenses, items, purchases } = data;
  const [dateRange, setDateRange] = useState('30');
  const { toast } = useToast();

  const getPurchaseCostForItem = useCallback((itemId) => {
    const allPurchasesForItem = (purchases || [])
      .filter(p => p && p.items)
      .flatMap(p => (p.items || []).map(item => ({ ...item, date: p.date })))
      .filter(item => item.itemId === itemId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    if (allPurchasesForItem.length > 0) {
      return allPurchasesForItem[0].price;
    }
    
    const itemMaster = (items || []).find(i => i.id === itemId);
    return itemMaster?.purchasePrice || 0;
  }, [purchases, items]);

  const filteredData = useMemo(() => {
    const days = parseInt(dateRange);
    const startDate = startOfDay(subDays(new Date(), days));
    const endDate = endOfDay(new Date());

    const filteredSales = (sales || []).filter(sale => {
      if (!sale || !sale.date) return false;
      const saleDate = new Date(sale.date);
      return saleDate >= startDate && saleDate <= endDate;
    });

    const filteredExpenses = (expenses || []).filter(expense => {
      if (!expense || !expense.date) return false;
      const expenseDate = new Date(expense.date);
      return expenseDate >= startDate && expenseDate <= endDate;
    });

    return { filteredSales, filteredExpenses };
  }, [dateRange, sales, expenses]);

  const dashboardData = useMemo(() => {
    const { filteredSales, filteredExpenses } = filteredData;

    const totalSales = filteredSales.reduce((sum, sale) => sum + (sale.totalCost || 0), 0);
    const totalExpenses = filteredExpenses.reduce((sum, expense) => sum + (expense.amount || 0), 0);

    const profitFromSales = filteredSales.reduce((sum, sale) => {
      const itemsCost = (sale.items || []).reduce((cost, saleItem) => {
        const purchasePrice = getPurchaseCostForItem(saleItem.itemId);
        return cost + (purchasePrice * (saleItem.quantity || 0));
      }, 0);
      return sum + ((sale.totalCost || 0) - itemsCost);
    }, 0);

    const netProfit = profitFromSales - totalExpenses;

    const stockValue = (items || []).reduce((sum, item) => {
      if (!item) return sum;
      const openingStock = item.openingStock || 0;
      const totalPurchased = (purchases || []).reduce((acc, p) => acc + ((p?.items || []).find(pi => pi.itemId === item.id)?.quantity || 0), 0);
      const totalSold = (sales || []).reduce((acc, s) => acc + ((s?.items || []).find(si => si.itemId === item.id)?.quantity || 0), 0);
      const currentStock = openingStock + totalPurchased - totalSold;
      return sum + (currentStock * (item.purchasePrice || 0));
    }, 0);

    return { totalSales, totalExpenses, netProfit, stockValue };
  }, [filteredData, items, purchases, sales, getPurchaseCostForItem]);

  const chartData = useMemo(() => {
    const days = parseInt(dateRange);
    const chartDays = [];
    for (let i = days - 1; i >= 0; i--) {
      const date = subDays(new Date(), i);
      const dayStart = startOfDay(date);
      const dayEnd = endOfDay(date);
      
      const daySales = (sales || []).filter(sale => {
        if (!sale || !sale.date) return false;
        const saleDate = new Date(sale.date);
        return saleDate >= dayStart && saleDate <= dayEnd;
      }).reduce((sum, sale) => sum + (sale.totalCost || 0), 0);

      const dayExpenses = (expenses || []).filter(expense => {
        if (!expense || !expense.date) return false;
        const expenseDate = new Date(expense.date);
        return expenseDate >= dayStart && expenseDate <= dayEnd;
      }).reduce((sum, expense) => sum + (expense.amount || 0), 0);
      
      const dayProfitFromSales = (sales || []).filter(sale => {
        if (!sale || !sale.date) return false;
        const saleDate = new Date(sale.date);
        return saleDate >= dayStart && saleDate <= dayEnd;
      }).reduce((sum, sale) => {
        const itemsCost = (sale.items || []).reduce((cost, saleItem) => {
          const purchasePrice = getPurchaseCostForItem(saleItem.itemId);
          return cost + (purchasePrice * (saleItem.quantity || 0));
        }, 0);
        return sum + ((sale.totalCost || 0) - itemsCost);
      }, 0);
      
      const dayProfit = dayProfitFromSales - dayExpenses;

      chartDays.push({
        date: format(date, 'MMM dd'),
        sales: daySales,
        expenses: dayExpenses,
        profit: dayProfit
      });
    }
    return chartDays;
  }, [dateRange, sales, expenses, items, getPurchaseCostForItem]);

  const expenseData = useMemo(() => {
    const { filteredExpenses } = filteredData;
    const expenseCategories = {};
    filteredExpenses.forEach(expense => {
      if (expense && expense.category) {
        expenseCategories[expense.category] = (expenseCategories[expense.category] || 0) + (expense.amount || 0);
      }
    });
    return Object.entries(expenseCategories).map(([category, amount]) => ({
      name: category,
      value: amount
    }));
  }, [filteredData]);

  const exportToPDF = () => {
    toast({
      title: "Export Feature",
      description: "🚧 PDF export isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀"
    });
  };

  const kpiCards = [
    {
      title: 'Total Sales',
      value: `RS ${dashboardData.totalSales.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: DollarSign,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Total Expenses',
      value: `RS ${dashboardData.totalExpenses.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: CreditCard,
      color: 'text-red-600',
      bgColor: 'bg-red-50'
    },
    {
      title: 'Net Profit',
      value: `RS ${dashboardData.netProfit.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: TrendingUp,
      color: dashboardData.netProfit >= 0 ? 'text-green-600' : 'text-red-600',
      bgColor: dashboardData.netProfit >= 0 ? 'bg-green-50' : 'bg-red-50'
    },
    {
      title: 'Stock Value',
      value: `RS ${dashboardData.stockValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      icon: Package,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Dashboard</h1>
          <p className="text-gray-600 mt-1">Business overview and analytics</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1">Today</SelectItem>
              <SelectItem value="7">Last 7 Days</SelectItem>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="90">Last 90 Days</SelectItem>
              <SelectItem value="365">This Year</SelectItem>
            </SelectContent>
          </Select>
          
          <Button onClick={exportToPDF} className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiCards.map((kpi, index) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={kpi.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">{kpi.title}</p>
                      <p className={`text-2xl font-bold ${kpi.color}`}>{kpi.value}</p>
                    </div>
                    <div className={`p-3 rounded-full ${kpi.bgColor}`}>
                      <Icon className={`h-6 w-6 ${kpi.color}`} />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Sales vs Expenses Trend</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value) => [`RS ${value.toLocaleString()}`, '']} />
                <Line type="monotone" dataKey="sales" stroke="#667eea" strokeWidth={3} name="Sales" />
                <Line type="monotone" dataKey="expenses" stroke="#f5576c" strokeWidth={3} name="Expenses" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Expense Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={expenseData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`RS ${value.toLocaleString()}`, 'Amount']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="card-hover lg:col-span-2">
          <CardHeader>
            <CardTitle>Profit Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip formatter={(value) => [`RS ${value.toLocaleString()}`, 'Profit']} />
                <Bar dataKey="profit">
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.profit >= 0 ? '#667eea' : '#f5576c'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default Dashboard;