import React, { useMemo, useState, useCallback } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Search, TrendingUp, TrendingDown } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { generatePdf } from '@/components/pdf/PdfGenerator';
import InvoiceProfitReportTemplate from '@/components/pdf/InvoiceProfitReportTemplate';

const InvoiceProfit = () => {
  const { data } = useData();
  const { sales, items, customers, settings, purchases } = data;
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const getPurchaseCostForItem = useCallback((itemId) => {
    const allPurchasesForItem = (purchases || [])
      .flatMap(p => p.items.map(item => ({ ...item, date: p.date })))
      .filter(item => item.itemId === itemId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    if (allPurchasesForItem.length > 0) {
      return allPurchasesForItem[0].price;
    }
    
    const itemMaster = items.find(i => i.id === itemId);
    return itemMaster?.purchasePrice || 0;
  }, [purchases, items]);

  const profitData = useMemo(() => {
    if (!sales || !items || !customers) return [];
    return sales.map(sale => {
      const itemsCost = (sale.items || []).reduce((cost, saleItem) => {
        const purchasePrice = getPurchaseCostForItem(saleItem.itemId);
        return cost + (purchasePrice * (saleItem.quantity || 0));
      }, 0);
      const revenue = sale.totalCost || 0;
      const profit = revenue - itemsCost;
      const customer = customers.find(c => c.id === sale.customerId);
      return {
        ...sale,
        customerName: customer?.name || 'Unknown',
        profit,
        itemsCost,
        revenue,
      };
    });
  }, [sales, items, customers, getPurchaseCostForItem]);

  const filteredProfitData = useMemo(() => {
    return profitData.filter(sale =>
      (sale.saleNumber && sale.saleNumber.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (sale.customerName && sale.customerName.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [profitData, searchTerm]);

  const totalProfit = useMemo(() => {
    return filteredProfitData.reduce((sum, sale) => sum + sale.profit, 0);
  }, [filteredProfitData]);

  const handleExport = () => {
    if (filteredProfitData.length === 0) {
      toast({ title: "No Data", description: "Cannot export an empty report.", variant: "destructive" });
      return;
    }
    generatePdf(
      <InvoiceProfitReportTemplate data={filteredProfitData} settings={settings} totalProfit={totalProfit} />,
      `Invoice-Profit-Report.pdf`
    );
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Invoice-wise Profit Report</CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by invoice or customer..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" /> Export PDF
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="p-2 text-left">Invoice #</th>
                <th className="p-2 text-left">Date</th>
                <th className="p-2 text-left">Customer</th>
                <th className="p-2 text-right">Revenue</th>
                <th className="p-2 text-right">Cost</th>
                <th className="p-2 text-right">Profit</th>
              </tr>
            </thead>
            <tbody>
              {filteredProfitData.map(sale => (
                <tr key={sale.id} className="border-b hover:bg-muted">
                  <td className="p-2 font-mono text-sm">{sale.saleNumber}</td>
                  <td className="p-2">{new Date(sale.date).toLocaleDateString()}</td>
                  <td className="p-2">{sale.customerName}</td>
                  <td className="p-2 text-right">RS {sale.revenue.toFixed(2)}</td>
                  <td className="p-2 text-right">RS {sale.itemsCost.toFixed(2)}</td>
                  <td className={`p-2 text-right font-semibold ${sale.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    <div className="flex justify-end items-center">
                      {sale.profit >= 0 ? <TrendingUp className="h-4 w-4 mr-1" /> : <TrendingDown className="h-4 w-4 mr-1" />}
                      RS {sale.profit.toFixed(2)}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="font-bold border-t-2">
                <td colSpan="5" className="p-2 text-right">Total Profit</td>
                <td className={`p-2 text-right ${totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  RS {totalProfit.toFixed(2)}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default InvoiceProfit;