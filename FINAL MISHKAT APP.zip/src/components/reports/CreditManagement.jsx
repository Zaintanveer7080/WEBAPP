import React, { useMemo, useState } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Search, AlertCircle } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from '@/components/ui/use-toast';
import { differenceInDays, parseISO } from 'date-fns';
import { generatePdf } from '@/components/pdf/PdfGenerator';
import CreditReportTemplate from '@/components/pdf/CreditReportTemplate';

const CreditManagement = () => {
  const { data, getInvoiceStatus } = useData();
  const { customers, suppliers, sales, purchases, settings } = data;
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const receivables = useMemo(() => {
    return (sales || [])
      .map(sale => {
        if (!sale) return null;
        const { balance } = getInvoiceStatus(sale);
        if (balance <= 0.01) return null;
        
        const customer = (customers || []).find(c => c.id === sale.customerId);
        const overdueDays = differenceInDays(new Date(), parseISO(sale.date));

        return { 
          id: sale.id, 
          name: customer?.name || 'Unknown Customer', 
          balance, 
          invoiceDate: sale.date, 
          overdueDays,
          invoiceNumber: sale.saleNumber
        };
      })
      .filter(Boolean);
  }, [sales, customers, getInvoiceStatus]);

  const payables = useMemo(() => {
    return (purchases || [])
      .map(purchase => {
        if (!purchase) return null;
        const { balance } = getInvoiceStatus(purchase);
        if (balance <= 0.01) return null;

        const supplier = (suppliers || []).find(s => s.id === purchase.supplierId);
        const overdueDays = differenceInDays(new Date(), parseISO(purchase.date));

        return { 
          id: purchase.id, 
          name: supplier?.name || 'Unknown Supplier', 
          balance, 
          invoiceDate: purchase.date, 
          overdueDays,
          invoiceNumber: purchase.purchaseNumber
        };
      })
      .filter(Boolean);
  }, [purchases, suppliers, getInvoiceStatus]);

  const filteredReceivables = receivables.filter(r => 
    r.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (r.invoiceNumber && r.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()))
  );
  const filteredPayables = payables.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (p.invoiceNumber && p.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const totalReceivables = filteredReceivables.reduce((sum, r) => sum + r.balance, 0);
  const totalPayables = filteredPayables.reduce((sum, p) => sum + p.balance, 0);

  const handleExport = (type) => {
    const reportData = type === 'Receivables' ? filteredReceivables : filteredPayables;
    const total = type === 'Receivables' ? totalReceivables : totalPayables;
    if (reportData.length === 0) {
      toast({ title: "No Data", description: "Cannot export an empty report.", variant: "destructive" });
      return;
    }
    generatePdf(
      <CreditReportTemplate data={reportData} type={type} total={total} settings={settings} />,
      `${type}-Report.pdf`
    );
  };
  
  const renderTable = (data, type) => (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b">
            <th className="p-2 text-left">Invoice #</th>
            <th className="p-2 text-left">{type === 'Receivables' ? 'Customer' : 'Supplier'}</th>
            <th className="p-2 text-right">Balance Due</th>
            <th className="p-2 text-left">Invoice Date</th>
            <th className="p-2 text-right">Overdue By (Days)</th>
          </tr>
        </thead>
        <tbody>
          {data.map(item => (
            <tr key={item.id} className="border-b hover:bg-muted">
              <td className="p-2 font-mono">{item.invoiceNumber}</td>
              <td className="p-2 font-medium">{item.name}</td>
              <td className="p-2 text-right font-semibold">RS {item.balance.toFixed(2)}</td>
              <td className="p-2">{item.invoiceDate ? new Date(item.invoiceDate).toLocaleDateString() : 'N/A'}</td>
              <td className={`p-2 text-right ${item.overdueDays > 30 ? 'text-red-600 font-bold' : item.overdueDays > 15 ? 'text-orange-600' : ''}`}>
                {item.overdueDays > 0 ? `${item.overdueDays} days` : '-'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );

  return (
    <Tabs defaultValue="receivables" className="w-full">
      <TabsList className="grid w-full grid-cols-2">
        <TabsTrigger value="receivables">Receivables</TabsTrigger>
        <TabsTrigger value="payables">Payables</TabsTrigger>
      </TabsList>
      <TabsContent value="receivables">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
                <CardTitle>Credit Receivables</CardTitle>
                <p className="text-sm text-muted-foreground">Total: <span className="font-bold text-green-600">RS {totalReceivables.toFixed(2)}</span></p>
            </div>
            <div className="flex items-center gap-2">
              <Input placeholder="Search customer/invoice..." className="w-48" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
              <Button variant="outline" onClick={() => handleExport('Receivables')}>
                <Download className="mr-2 h-4 w-4" /> Export PDF
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {renderTable(filteredReceivables, 'Receivables')}
            {filteredReceivables.length > 5 && <div className="mt-2 text-sm text-muted-foreground flex items-center"><AlertCircle className="h-4 w-4 mr-2" />Overdue payments are highlighted.</div>}
          </CardContent>
        </Card>
      </TabsContent>
      <TabsContent value="payables">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Credit Payables</CardTitle>
              <p className="text-sm text-muted-foreground">Total: <span className="font-bold text-red-600">RS {totalPayables.toFixed(2)}</span></p>
            </div>
            <div className="flex items-center gap-2">
              <Input placeholder="Search supplier/invoice..." className="w-48" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
              <Button variant="outline" onClick={() => handleExport('Payables')}>
                <Download className="mr-2 h-4 w-4" /> Export PDF
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {renderTable(filteredPayables, 'Payables')}
             {filteredPayables.length > 5 && <div className="mt-2 text-sm text-muted-foreground flex items-center"><AlertCircle className="h-4 w-4 mr-2" />Overdue payments are highlighted.</div>}
          </CardContent>
        </Card>
      </TabsContent>
    </Tabs>
  );
};

export default CreditManagement;