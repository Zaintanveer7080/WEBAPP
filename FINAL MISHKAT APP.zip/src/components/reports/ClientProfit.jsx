import React, { useMemo, useState, useCallback } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Search, DollarSign } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { generatePdf } from '@/components/pdf/PdfGenerator';
import ClientProfitReportTemplate from '@/components/pdf/ClientProfitReportTemplate';

const ClientProfit = () => {
  const { data } = useData();
  const { sales, items, customers, settings, purchases } = data;
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const getPurchaseCostForItem = useCallback((itemId) => {
    const allPurchasesForItem = (purchases || [])
      .flatMap(p => p.items.map(item => ({ ...item, date: p.date })))
      .filter(item => item.itemId === itemId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    if (allPurchasesForItem.length > 0) {
      return allPurchasesForItem[0].price;
    }
    
    const itemMaster = items.find(i => i.id === itemId);
    return itemMaster?.purchasePrice || 0;
  }, [purchases, items]);

  const clientProfitData = useMemo(() => {
    if (!customers || !sales || !items) return [];
    const profitByClient = customers.map(customer => {
      const clientSales = sales.filter(s => s.customerId === customer.id);
      let totalProfit = 0;
      let totalRevenue = 0;
      const saleDetails = clientSales.map(sale => {
        const itemsCost = (sale.items || []).reduce((cost, saleItem) => {
          const purchasePrice = getPurchaseCostForItem(saleItem.itemId);
          return cost + (purchasePrice * saleItem.quantity);
        }, 0);
        const revenue = sale.totalCost;
        const profit = revenue - itemsCost;
        totalProfit += profit;
        totalRevenue += revenue;
        return { ...sale, profit, revenue };
      });

      return {
        ...customer,
        totalProfit,
        totalRevenue,
        totalSales: clientSales.length,
        saleDetails,
      };
    });
    return profitByClient.filter(c => c.totalSales > 0);
  }, [sales, items, customers, getPurchaseCostForItem]);

  const filteredClientData = useMemo(() => {
    return clientProfitData.filter(client =>
      client.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [clientProfitData, searchTerm]);

  const grandTotalProfit = useMemo(() => {
    return filteredClientData.reduce((sum, client) => sum + client.totalProfit, 0);
  }, [filteredClientData]);

  const handleExport = () => {
    if (filteredClientData.length === 0) {
      toast({ title: "No Data", description: "Cannot export an empty report.", variant: "destructive" });
      return;
    }
    generatePdf(
      <ClientProfitReportTemplate data={filteredClientData} settings={settings} grandTotalProfit={grandTotalProfit} />,
      `Client-Profit-Report.pdf`
    );
  };
  
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Client-wise Profit Report</CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by client name..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" /> Export PDF
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {filteredClientData.map(client => (
            <AccordionItem value={client.id} key={client.id}>
              <AccordionTrigger>
                <div className="flex justify-between w-full pr-4">
                  <span className="font-semibold">{client.name}</span>
                  <div className="flex items-center gap-4">
                    <span className="text-sm text-muted-foreground">Sales: {client.totalSales}</span>
                    <span className={`font-bold ${client.totalProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      Profit: RS {client.totalProfit.toFixed(2)}
                    </span>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="p-4 bg-muted rounded-md">
                   <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="p-2 text-left">Invoice #</th>
                          <th className="p-2 text-left">Date</th>
                          <th className="p-2 text-right">Revenue</th>
                          <th className="p-2 text-right">Profit</th>
                        </tr>
                      </thead>
                      <tbody>
                        {client.saleDetails.map(sale => (
                          <tr key={sale.id} className="border-b">
                            <td className="p-2 font-mono">{sale.saleNumber}</td>
                            <td className="p-2">{new Date(sale.date).toLocaleDateString()}</td>
                            <td className="p-2 text-right">RS {sale.revenue.toFixed(2)}</td>
                            <td className={`p-2 text-right font-medium ${sale.profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>RS {sale.profit.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                   </table>
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
        <div className="mt-4 pt-4 border-t-2 flex justify-end font-bold text-lg">
          <div className="flex items-center gap-4">
            <span>Grand Total Profit:</span>
            <span className={grandTotalProfit >= 0 ? 'text-green-600' : 'text-red-600'}>RS {grandTotalProfit.toFixed(2)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ClientProfit;