import React, { useMemo, useState } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Download, Search, AlertTriangle, CheckCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { generatePdf } from '@/components/pdf/PdfGenerator';
import StockSummaryReportTemplate from '@/components/pdf/StockSummaryReportTemplate';

const StockSummary = () => {
  const { data } = useData();
  const { items, purchases, sales, settings } = data;
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const stockData = useMemo(() => {
    if (!items) return [];
    return items.map(item => {
      const openingStock = item.openingStock || 0;
      const totalPurchased = (purchases || []).reduce((sum, p) => sum + ((p.items || []).find(pi => pi.itemId === item.id)?.quantity || 0), 0);
      const totalSold = (sales || []).reduce((sum, s) => sum + ((s.items || []).find(si => si.itemId === item.id)?.quantity || 0), 0);
      const currentStock = openingStock + totalPurchased - totalSold;
      const stockValue = currentStock * (item.purchasePrice || 0);

      let status = 'In Stock';
      if (currentStock <= 0) status = 'Out of Stock';
      else if (item.lowStockThreshold && currentStock <= item.lowStockThreshold) status = 'Low Stock';
      else if (currentStock <= 5) status = 'Low Stock';


      return {
        ...item,
        currentStock,
        totalPurchased,
        totalSold,
        stockValue,
        status,
      };
    });
  }, [items, purchases, sales]);

  const filteredStock = useMemo(() => {
    return stockData.filter(item =>
      (item.name && item.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.sku && item.sku.toLowerCase().includes(searchTerm.toLowerCase()))
    );
  }, [stockData, searchTerm]);

  const totalStockValue = useMemo(() => {
    return filteredStock.reduce((sum, item) => sum + item.stockValue, 0);
  }, [filteredStock]);

  const handleExport = () => {
    if (filteredStock.length === 0) {
      toast({ title: "No Data", description: "Cannot export an empty report.", variant: "destructive" });
      return;
    }
    generatePdf(
      <StockSummaryReportTemplate data={filteredStock} settings={settings} totalValue={totalStockValue} />,
      `Stock-Summary-Report.pdf`
    );
  };

  const getStatusIndicator = (status) => {
    switch (status) {
      case 'Out of Stock':
        return <div className="flex items-center text-red-600"><AlertTriangle className="h-4 w-4 mr-1" /><span className="text-xs">{status}</span></div>;
      case 'Low Stock':
        return <div className="flex items-center text-orange-600"><AlertTriangle className="h-4 w-4 mr-1" /><span className="text-xs">{status}</span></div>;
      default:
        return <div className="flex items-center text-green-600"><CheckCircle className="h-4 w-4 mr-1" /><span className="text-xs">{status}</span></div>;
    }
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>Stock Summary Report</CardTitle>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or SKU..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <Button variant="outline" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" /> Export PDF
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="p-2 text-left">SKU</th>
                <th className="p-2 text-left">Item Name</th>
                <th className="p-2 text-right">Quantity</th>
                <th className="p-2 text-right">Purchase Price</th>
                <th className="p-2 text-right">Sale Price</th>
                <th className="p-2 text-right">Total Value</th>
                <th className="p-2 text-left">Status</th>
              </tr>
            </thead>
            <tbody>
              {filteredStock.map(item => (
                <tr key={item.id} className="border-b hover:bg-muted">
                  <td className="p-2 font-mono text-sm">{item.sku}</td>
                  <td className="p-2 font-medium">{item.name}</td>
                  <td className="p-2 text-right">{item.currentStock} {item.unit}</td>
                  <td className="p-2 text-right">RS {item.purchasePrice?.toFixed(2)}</td>
                  <td className="p-2 text-right">RS {item.salePrice?.toFixed(2)}</td>
                  <td className="p-2 text-right font-semibold">RS {item.stockValue.toFixed(2)}</td>
                  <td className="p-2">{getStatusIndicator(item.status)}</td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="font-bold border-t-2">
                <td colSpan="5" className="p-2 text-right">Total Stock Value</td>
                <td className="p-2 text-right">RS {totalStockValue.toFixed(2)}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </CardContent>
    </Card>
  );
};

export default StockSummary;