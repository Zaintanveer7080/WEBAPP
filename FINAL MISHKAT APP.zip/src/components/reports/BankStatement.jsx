import React, { useMemo, useState, useEffect } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Download, Search, Landmark, TrendingUp, ShoppingCart, CreditCard, ArrowLeftRight, Wallet } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { format, startOfMonth, endOfMonth } from 'date-fns';
import { generatePdf } from '@/components/pdf/PdfGenerator';
import BankStatementTemplate from '@/components/pdf/BankStatementTemplate';

const BankStatement = () => {
  const { data } = useData();
  const { banks, payments, sales, purchases, expenses, customers, suppliers, settings } = data;
  const { toast } = useToast();
  
  const [selectedBankId, setSelectedBankId] = useState('');
  const [dateRange, setDateRange] = useState({
    from: format(startOfMonth(new Date()), 'yyyy-MM-dd'),
    to: format(endOfMonth(new Date()), 'yyyy-MM-dd'),
  });
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (!selectedBankId && banks.length > 0) {
      setSelectedBankId(banks[0].id);
    }
  }, [banks, selectedBankId]);

  const transactions = useMemo(() => {
    if (!selectedBankId) return [];
    
    const txs = [];
    (sales || []).forEach(s => {
        if (s.paidAmount > 0 && s.payment.method === 'bank' && s.payment.bankId === selectedBankId) txs.push({
            id: `sale-${s.id}`, date: s.date, type: 'Sale',
            description: `Sale #${s.saleNumber} to ${customers.find(c=>c.id === s.customerId)?.name || ''}`,
            amount: s.paidAmount, flow: 'in',
        });
    });
    (purchases || []).forEach(p => {
        if (p.paidAmount > 0 && p.payment.method === 'bank' && p.payment.bankId === selectedBankId) txs.push({
            id: `purchase-${p.id}`, date: p.date, type: 'Purchase',
            description: `Purchase #${p.purchaseNumber} from ${suppliers.find(sup=>sup.id === p.supplierId)?.name || ''}`,
            amount: p.paidAmount, flow: 'out',
        });
    });
    (payments || []).forEach(p => {
        if (p.method === 'bank' && p.bankId === selectedBankId) {
            const partyName = p.type === 'in' ? customers.find(c=>c.id === p.partyId)?.name : suppliers.find(sup=>sup.id === p.partyId)?.name;
            txs.push({
                id: `payment-${p.id}`, date: p.date, type: 'Payment',
                description: `Payment ${p.type === 'in' ? 'In' : 'Out'} - ${partyName || ''}`,
                amount: p.amount, flow: p.type,
            });
        }
    });
    
    return txs.sort((a,b) => new Date(a.date) - new Date(b.date));

  }, [selectedBankId, payments, sales, purchases, customers, suppliers]);

  const filteredTransactions = useMemo(() => {
    const fromDate = dateRange.from ? new Date(dateRange.from) : null;
    if(fromDate) fromDate.setHours(0,0,0,0);
    const toDate = dateRange.to ? new Date(dateRange.to) : null;
    if(toDate) toDate.setHours(23,59,59,999);
    
    return transactions.filter(t => {
        const txDate = new Date(t.date);
        if (fromDate && txDate < fromDate) return false;
        if (toDate && txDate > toDate) return false;
        return t.description.toLowerCase().includes(searchTerm.toLowerCase());
    });
  }, [transactions, dateRange, searchTerm]);

  const selectedBank = banks.find(b => b.id === selectedBankId);

  const transactionsWithBalance = useMemo(() => {
    if (!selectedBank) return [];
    let runningBalance = selectedBank.balance;
    
    const reversedTxs = [...filteredTransactions].reverse();
    const txsWithBalance = reversedTxs.map(tx => {
        const currentBalance = runningBalance;
        if (tx.flow === 'in') {
            runningBalance -= tx.amount;
        } else {
            runningBalance += tx.amount;
        }
        return { ...tx, balance: currentBalance };
    });

    return txsWithBalance.reverse();
  }, [filteredTransactions, selectedBank]);

  const handleExport = () => {
    if (!selectedBank || transactionsWithBalance.length === 0) {
      toast({ title: "No Data", description: "Cannot export an empty report.", variant: "destructive" });
      return;
    }
    generatePdf(
      <BankStatementTemplate 
        transactions={transactionsWithBalance} 
        bank={selectedBank} 
        dateRange={dateRange} 
        settings={settings} 
      />,
      `Bank-Statement-${selectedBank.name}.pdf`
    );
  };

  const TransactionIcon = ({ type }) => {
    switch (type) {
        case 'Sale': return <TrendingUp className="h-5 w-5 text-green-500" />;
        case 'Purchase': return <ShoppingCart className="h-5 w-5 text-red-500" />;
        case 'Expense': return <CreditCard className="h-5 w-5 text-orange-500" />;
        case 'Payment': return <ArrowLeftRight className="h-5 w-5 text-blue-500" />;
        default: return <Wallet className="h-5 w-5 text-gray-500" />;
    }
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Bank Statement</CardTitle>
        <div className="flex flex-wrap items-center gap-4 pt-4">
            <Select value={selectedBankId} onValueChange={setSelectedBankId}>
                <SelectTrigger className="w-48"><SelectValue placeholder="Select Bank" /></SelectTrigger>
                <SelectContent>
                    {banks.map(bank => <SelectItem key={bank.id} value={bank.id}>{bank.name}</SelectItem>)}
                </SelectContent>
            </Select>
            <Input type="date" value={dateRange.from} onChange={e => setDateRange({...dateRange, from: e.target.value})} className="w-40" />
            <Input type="date" value={dateRange.to} onChange={e => setDateRange({...dateRange, to: e.target.value})} className="w-40" />
            <div className="relative flex-grow">
                <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input placeholder="Search description..." className="pl-8" value={searchTerm} onChange={e => setSearchTerm(e.target.value)}/>
            </div>
            <Button variant="outline" onClick={handleExport}>
                <Download className="mr-2 h-4 w-4" /> Export PDF
            </Button>
        </div>
      </CardHeader>
      <CardContent>
        {selectedBank && (
            <div className="mb-4 p-4 bg-muted rounded-lg flex justify-between items-center">
                <h3 className="text-lg font-semibold flex items-center"><Landmark className="mr-2 h-5 w-5"/>{selectedBank.name}</h3>
                <p className="text-xl font-bold">Current Balance: RS {selectedBank.balance.toFixed(2)}</p>
            </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b">
                <th className="p-2 text-left">Date</th>
                <th className="p-2 text-left">Transaction Details</th>
                <th className="p-2 text-right">Debit</th>
                <th className="p-2 text-right">Credit</th>
                <th className="p-2 text-right">Balance</th>
              </tr>
            </thead>
            <tbody>
              {transactionsWithBalance.map((tx) => (
                <tr key={tx.id} className="border-b hover:bg-muted">
                  <td className="p-2">{format(new Date(tx.date), 'PPpp')}</td>
                  <td className="p-2">
                    <div className="flex items-center gap-2">
                        <TransactionIcon type={tx.type} />
                        <div>
                            <p className="font-medium">{tx.description}</p>
                            <p className="text-xs text-muted-foreground">{tx.type}</p>
                        </div>
                    </div>
                  </td>
                  <td className="p-2 text-right text-red-600">
                    {tx.flow === 'out' ? `RS ${tx.amount.toFixed(2)}` : '-'}
                  </td>
                  <td className="p-2 text-right text-green-600">
                    {tx.flow === 'in' ? `RS ${tx.amount.toFixed(2)}` : '-'}
                  </td>
                  <td className="p-2 text-right font-mono">RS {tx.balance.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {transactionsWithBalance.length === 0 && <p className="text-center p-4 text-muted-foreground">No transactions found for the selected criteria.</p>}
        </div>
      </CardContent>
    </Card>
  );
};

export default BankStatement;