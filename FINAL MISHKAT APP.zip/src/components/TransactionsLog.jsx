import React, { useMemo, useState } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Eye, Landmark, Wallet, ArrowUpRight, ArrowDownRight, TrendingUp, ShoppingCart, CreditCard, ArrowLeftRight, Filter } from 'lucide-react';
import { motion } from 'framer-motion';

const TransactionIcon = ({ type, method }) => {
    switch (type) {
        case 'Sale': return <TrendingUp className="h-5 w-5 text-green-500" />;
        case 'Purchase': return <ShoppingCart className="h-5 w-5 text-red-500" />;
        case 'Expense': return <CreditCard className="h-5 w-5 text-red-500" />;
        case 'Payment': return <ArrowLeftRight className="h-5 w-5 text-blue-500" />;
        case 'Manual':
            return method === 'cash' 
                ? <Wallet className="h-5 w-5 text-yellow-500" />
                : <Landmark className="h-5 w-5 text-purple-500" />;
        default: return <Wallet className="h-5 w-5 text-gray-500" />;
    }
};

const transactionTypes = ['Sale', 'Purchase', 'Expense', 'Payment', 'Manual'];
const transactionMethods = ['Cash', 'Bank'];

const TransactionsLog = () => {
    const { data, setTransactionToView } = useData();
    const { sales, purchases, expenses, payments, cashTransactions, customers, suppliers, banks } = data;

    const [filters, setFilters] = useState({
        startDate: '',
        endDate: '',
        types: transactionTypes,
        methods: transactionMethods,
    });

    const handleFilterChange = (field, value) => {
        setFilters(prev => ({ ...prev, [field]: value }));
    };

    const handleTypeToggle = (type) => {
        setFilters(prev => ({
            ...prev,
            types: prev.types.includes(type) ? prev.types.filter(t => t !== type) : [...prev.types, type]
        }));
    };
    
    const handleMethodToggle = (method) => {
        setFilters(prev => ({
            ...prev,
            methods: prev.methods.includes(method) ? prev.methods.filter(m => m !== method) : [...prev.methods, method]
        }));
    };

    const combinedTransactions = useMemo(() => {
        const allTransactions = [];

        (sales || []).forEach(sale => {
            if (sale.paidAmount > 0) {
                allTransactions.push({
                    id: `sale-payment-${sale.id}`,
                    date: sale.date,
                    type: 'Sale',
                    description: `Payment for Sale #${sale.saleNumber} to ${customers.find(c => c.id === sale.customerId)?.name || 'N/A'}`,
                    amount: sale.paidAmount,
                    flow: 'in',
                    method: sale.payment?.method === 'bank' ? 'Bank' : 'Cash',
                    bankName: sale.payment?.method === 'bank' ? banks.find(b => b.id === sale.payment.bankId)?.name : null,
                    ref: sale,
                    refType: 'sale'
                });
            }
        });

        (purchases || []).forEach(purchase => {
            if (purchase.paidAmount > 0) {
                 allTransactions.push({
                    id: `purchase-payment-${purchase.id}`,
                    date: purchase.date,
                    type: 'Purchase',
                    description: `Payment for Purchase #${purchase.purchaseNumber} from ${suppliers.find(s => s.id === purchase.supplierId)?.name || 'N/A'}`,
                    amount: purchase.paidAmount,
                    flow: 'out',
                    method: purchase.payment?.method === 'bank' ? 'Bank' : 'Cash',
                    bankName: purchase.payment?.method === 'bank' ? banks.find(b => b.id === purchase.payment.bankId)?.name : null,
                    ref: purchase,
                    refType: 'purchase'
                });
            }
        });

        (payments || []).forEach(p => {
             const partyName = p.type === 'in'
                ? customers.find(c => c.id === p.partyId)?.name
                : suppliers.find(s => s.id === p.partyId)?.name;
            allTransactions.push({
                id: `payment-${p.id}`,
                date: p.date,
                type: 'Payment',
                description: `Payment ${p.type === 'in' ? 'In from' : 'Out to'} ${partyName || 'N/A'}`,
                amount: p.amount,
                flow: p.type,
                method: p.method === 'bank' ? 'Bank' : 'Cash',
                bankName: p.method === 'bank' ? banks.find(b => b.id === p.bankId)?.name : null,
                ref: p,
                refType: 'payment'
            });
        });

        (expenses || []).forEach(expense => {
            allTransactions.push({
                id: `expense-${expense.id}`,
                date: expense.date,
                type: 'Expense',
                description: `Expense: ${expense.category}`,
                amount: expense.amount,
                flow: 'out',
                method: 'Cash',
                ref: expense,
                refType: 'expense'
            });
        });

        (cashTransactions || []).forEach(tx => {
            allTransactions.push({
                id: `cash-${tx.id}`,
                date: tx.date,
                type: 'Manual',
                description: tx.description,
                amount: tx.amount,
                flow: tx.type === 'add' ? 'in' : 'out',
                method: 'Cash',
                ref: tx,
                refType: 'cash'
            });
        });

        return allTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));
    }, [sales, purchases, expenses, payments, cashTransactions, customers, suppliers, banks]);

    const filteredTransactions = useMemo(() => {
        return combinedTransactions.filter(tx => {
            const txDate = new Date(tx.date);
            txDate.setHours(0, 0, 0, 0);

            const startDate = filters.startDate ? new Date(filters.startDate) : null;
            if(startDate) startDate.setHours(0,0,0,0);
            
            const endDate = filters.endDate ? new Date(filters.endDate) : null;
            if(endDate) endDate.setHours(0,0,0,0);

            if(startDate && !endDate && txDate.getTime() !== startDate.getTime()) return false;
            if(startDate && endDate && (txDate < startDate || txDate > endDate)) return false;

            if (!filters.types.includes(tx.type)) return false;
            if (!filters.methods.includes(tx.method)) return false;

            return true;
        });
    }, [combinedTransactions, filters]);

    const totals = useMemo(() => {
        const totalIn = filteredTransactions.reduce((sum, tx) => tx.flow === 'in' ? sum + tx.amount : sum, 0);
        const totalOut = filteredTransactions.reduce((sum, tx) => tx.flow === 'out' ? sum + tx.amount : sum, 0);
        return { totalIn, totalOut, netFlow: totalIn - totalOut };
    }, [filteredTransactions]);

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold gradient-text">Transactions Log</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-1">A unified view of all financial activities.</p>
            </div>

            <Card>
                <CardHeader>
                    <CardTitle>Filters</CardTitle>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-4">
                        <div>
                            <label className="text-sm font-medium">Date Range</label>
                            <div className="flex gap-2">
                                <Input type="date" value={filters.startDate} onChange={e => handleFilterChange('startDate', e.target.value)} />
                                <Input type="date" value={filters.endDate} onChange={e => handleFilterChange('endDate', e.target.value)} />
                            </div>
                        </div>
                        <div>
                            <label className="text-sm font-medium">Transaction Types</label>
                            <div className="flex flex-wrap gap-2 pt-2">
                                {transactionTypes.map(type => (
                                    <div key={type} className="flex items-center space-x-2">
                                        <Checkbox id={`type-${type}`} checked={filters.types.includes(type)} onCheckedChange={() => handleTypeToggle(type)} />
                                        <label htmlFor={`type-${type}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{type}</label>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div>
                            <label className="text-sm font-medium">Payment Methods</label>
                             <div className="flex flex-wrap gap-2 pt-2">
                                {transactionMethods.map(method => (
                                    <div key={method} className="flex items-center space-x-2">
                                        <Checkbox id={`method-${method}`} checked={filters.methods.includes(method)} onCheckedChange={() => handleMethodToggle(method)} />
                                        <label htmlFor={`method-${method}`} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">{method}</label>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                        {filteredTransactions.length === 0 ? (
                            <p className="text-center text-gray-500 py-8">No transactions match the current filters.</p>
                        ) : (
                            filteredTransactions.map((tx, index) => (
                                <motion.div
                                    key={tx.id}
                                    initial={{ opacity: 0, y: 10 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: index * 0.05 }}
                                    className="flex items-center justify-between p-3 bg-muted rounded-lg"
                                >
                                    <div className="flex items-center gap-4">
                                        <div className="flex-shrink-0">
                                            <TransactionIcon type={tx.type} method={tx.method} />
                                        </div>
                                        <div>
                                            <p className="font-semibold">{tx.description}</p>
                                            <p className="text-xs text-muted-foreground">
                                                {new Date(tx.date).toLocaleString()}
                                                {tx.method === 'Bank' && tx.bankName && ` • ${tx.bankName}`}
                                            </p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <p className={`font-bold text-lg flex items-center gap-1 ${tx.flow === 'in' ? 'text-green-500' : 'text-red-500'}`}>
                                            {tx.flow === 'in' ? <ArrowUpRight className="h-4 w-4" /> : <ArrowDownRight className="h-4 w-4" />}
                                            RS {tx.amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                                        </p>
                                        <Button variant="ghost" size="icon" onClick={() => setTransactionToView({ transaction: tx.ref, type: tx.refType })}>
                                            <Eye className="h-4 w-4 text-purple-500" />
                                        </Button>
                                    </div>
                                </motion.div>
                            ))
                        )}
                    </div>
                </CardContent>
                 <CardFooter className="flex justify-end gap-6 font-bold pt-4 border-t">
                    <div className="text-green-500">Total In: RS {totals.totalIn.toFixed(2)}</div>
                    <div className="text-red-500">Total Out: RS {totals.totalOut.toFixed(2)}</div>
                    <div className={totals.netFlow >= 0 ? 'text-blue-500' : 'text-orange-500'}>Net Flow: RS {totals.netFlow.toFixed(2)}</div>
                </CardFooter>
            </Card>
        </div>
    );
};

export default TransactionsLog;