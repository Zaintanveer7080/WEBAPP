
import React, { useState, useMemo } from 'react';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Plus, Edit, Trash2, TrendingUp, FileDown, Eye } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import SalesForm from '@/components/sales/SalesForm';
import FormPanel from '@/components/FormPanel';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { generatePdf } from '@/components/pdf/PdfGenerator';
import SaleInvoiceTemplate from '@/components/pdf/SaleInvoiceTemplate';

const PaymentStatusBadge = ({ status }) => {
  const statusStyles = {
    Paid: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
    Partial: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
    Credit: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
  };
  return (
    <span className={`inline-flex items-center px-2 py-1 text-xs font-medium rounded-full ${statusStyles[status] || ''}`}>
      {status}
    </span>
  );
};

function Sales() {
  const { data, updateData, requestPasscode, setTransactionToView, getInvoiceStatus } = useData();
  const { sales, customers, items, payments } = data;
  const { toast } = useToast();

  const [view, setView] = useState('list');
  const [editingSale, setEditingSale] = useState(null);

  const handleDownloadPdf = (sale) => {
    const customer = customers.find(c => c.id === sale.customerId);
    generatePdf(
      <SaleInvoiceTemplate sale={sale} customer={customer} items={items} settings={data.settings} getInvoiceStatus={getInvoiceStatus} />,
      `Sale-Invoice-${sale.saleNumber}.pdf`
    );
  };

  const getCustomerName = (customerId) => customers.find(c => c.id === customerId)?.name || 'Unknown';
  
  const handleEdit = (sale) => {
    requestPasscode(() => {
        setEditingSale(sale);
        setView('form');
    });
  };
  
  const handleDelete = (id) => {
    requestPasscode(() => {
        const updatedSales = sales.filter(s => s.id !== id);
        const updatedPayments = payments.filter(p => p.invoiceId !== id);
        updateData({ sales: updatedSales, payments: updatedPayments });
        toast({ title: "Success", description: "Sale and associated payments deleted successfully." });
    });
  };
  
  const handleAddNew = () => {
    setEditingSale(null);
    setView('form');
  }

  const handleCloseForm = () => {
    setView('list');
    setEditingSale(null);
  }

  const salesList = useMemo(() => {
    return (sales || []).map(s => ({
        ...s,
        customerName: getCustomerName(s.customerId),
        statusInfo: getInvoiceStatus(s)
    })).reverse();
  }, [sales, customers, getInvoiceStatus]);


  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Sales Management</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Create and manage your sales invoices.</p>
        </div>
        <Button onClick={handleAddNew}>
          <Plus className="h-4 w-4 mr-2" />
          New Sale
        </Button>
      </div>

      <AnimatePresence mode="wait">
        {view === 'list' && (
          <motion.div
            key="list"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1"
          >
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Sales History
                </CardTitle>
              </CardHeader>
              <CardContent>
                {salesList.length === 0 ? (
                  <div className="text-center py-8">
                    <TrendingUp className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-gray-500">No sales found. Create your first sale!</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Inv #</th>
                          <th className="text-left p-2">Date</th>
                          <th className="text-left p-2">Customer</th>
                          <th className="text-right p-2">Total Bill</th>
                          <th className="text-right p-2">Paid Amount</th>
                          <th className="text-center p-2">Status</th>
                          <th className="text-center p-2">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        {salesList.map((sale, index) => (
                          <motion.tr
                            key={sale.id}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.05 }}
                            className="border-b hover:bg-muted"
                          >
                            <td className="p-2 font-mono">{sale.saleNumber}</td>
                            <td className="p-2">{new Date(sale.date).toLocaleDateString()}</td>
                            <td className="p-2">{sale.customerName}</td>
                            <td className="p-2 font-semibold text-right text-blue-600">RS {sale.totalCost.toFixed(2)}</td>
                            <td className="p-2 font-semibold text-right text-green-600">RS {sale.paidAmount.toFixed(2)}</td>
                            <td className="p-2 text-center"><PaymentStatusBadge status={sale.statusInfo.status} /></td>
                            <td className="p-2">
                              <div className="flex justify-center space-x-1">
                                <Button size="icon" variant="ghost" onClick={() => setTransactionToView({ transaction: sale, type: 'sale' })}><Eye className="h-4 w-4 text-purple-500" /></Button>
                                <Button size="icon" variant="ghost" onClick={() => handleEdit(sale)}><Edit className="h-4 w-4" /></Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button size="icon" variant="ghost"><Trash2 className="h-4 w-4 text-red-500" /></Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        This will delete the sale invoice and all associated payments. This action cannot be undone.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancel</AlertDialogCancel>
                                      <AlertDialogAction onClick={() => handleDelete(sale.id)}>Delete</AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                                <Button size="icon" variant="ghost" onClick={() => handleDownloadPdf(sale)}>
                                  <FileDown className="h-4 w-4 text-blue-500" />
                                </Button>
                              </div>
                            </td>
                          </motion.tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>
        )}

        {view === 'form' && (
          <FormPanel
            key="form"
            title={editingSale ? 'Edit Sale Invoice' : 'New Sale Invoice'}
            onClose={handleCloseForm}
          >
            <SalesForm
              sale={editingSale}
              onClose={handleCloseForm}
            />
          </FormPanel>
        )}
      </AnimatePresence>
    </div>
  );
}

export default Sales;
