
import React, { useState, useMemo, useEffect } from 'react';
import { useData } from '@/contexts/DataContext';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, Landmark, Wallet } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { motion } from 'framer-motion';
import TransactionLog from '@/components/cash-and-bank/TransactionLog';

const BankAccountsCard = ({ banks, onAdd, onEdit, onDelete }) => (
    <Card className="card-hover lg:col-span-2">
        <CardHeader>
            <CardTitle className="flex items-center justify-between text-lg">
                <div className="flex items-center"><Landmark className="h-5 w-5 mr-2 text-blue-500"/>Bank Accounts</div>
                <Button size="sm" onClick={onAdd}><Plus className="h-4 w-4 mr-1"/> Add Bank</Button>
            </CardTitle>
        </CardHeader>
        <CardContent>
            <div className="space-y-4 max-h-48 overflow-y-auto">
                {banks.length === 0 ? (
                    <p className="text-center text-gray-500 py-4">No bank accounts added yet.</p>
                ) : (
                    banks.map(bank => (
                        <motion.div key={bank.id} className="flex justify-between items-center p-3 bg-muted rounded-lg">
                            <div>
                                <p className="font-semibold">{bank.name}</p>
                                <p className="text-xl font-bold text-blue-500">RS {bank.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                            </div>
                            <div className="flex gap-2">
                                <Button variant="ghost" size="icon" onClick={() => onEdit(bank)}><Edit className="h-4 w-4"/></Button>
                                <Button variant="ghost" size="icon" onClick={() => onDelete(bank.id)}><Trash2 className="h-4 w-4 text-red-500"/></Button>
                            </div>
                        </motion.div>
                    ))
                )}
            </div>
        </CardContent>
    </Card>
);

const CashInHandCard = ({ cashInHand, onAdjust }) => (
    <Card className="card-hover lg:col-span-1">
        <CardHeader>
            <CardTitle className="flex items-center text-lg"><Wallet className="h-5 w-5 mr-2 text-green-500"/>Cash in Hand</CardTitle>
        </CardHeader>
        <CardContent>
            <p className="text-4xl font-bold text-green-500">RS {cashInHand.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </CardContent>
        <CardFooter>
            <Button size="sm" onClick={onAdjust}>Adjust Cash</Button>
        </CardFooter>
    </Card>
);

const BankDialog = ({ isOpen, onOpenChange, onSubmit, editingBank, formData, setFormData }) => (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent>
            <DialogHeader><DialogTitle>{editingBank ? 'Edit Bank' : 'Add New Bank'}</DialogTitle></DialogHeader>
            <form onSubmit={onSubmit} className="py-4 space-y-4">
                <div><Label htmlFor="bankName">Bank Name</Label><Input id="bankName" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="e.g., HDFC Bank" /></div>
                <div><Label htmlFor="balance">{editingBank ? 'Current Balance' : 'Opening Balance'}</Label><Input id="balance" type="number" value={formData.balance} onChange={e => setFormData({...formData, balance: e.target.value})} placeholder="e.g., 50000" /></div>
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button type="submit">{editingBank ? 'Update Bank' : 'Add Bank'}</Button>
                </DialogFooter>
            </form>
        </DialogContent>
    </Dialog>
);

const CashDialog = ({ isOpen, onOpenChange, onSubmit, editingTx, formData, setFormData }) => (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
        <DialogContent>
            <DialogHeader><DialogTitle>{editingTx ? 'Edit Cash Transaction' : 'Adjust Cash in Hand'}</DialogTitle></DialogHeader>
            <form onSubmit={onSubmit} className="py-4 space-y-4">
                <Tabs value={formData.type} onValueChange={(type) => setFormData({...formData, type})} className="w-full">
                    <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="add">Add Cash</TabsTrigger>
                        <TabsTrigger value="remove">Remove Cash</TabsTrigger>
                    </TabsList>
                </Tabs>
                <div><Label htmlFor="cashAmount">Amount</Label><Input id="cashAmount" type="number" value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})} placeholder="e.g., 5000" /></div>
                <div><Label htmlFor="cashDesc">Description</Label><Input id="cashDesc" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} placeholder="e.g., Initial cash deposit" /></div>
                <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
                    <Button type="submit">{editingTx ? 'Update Transaction' : 'Submit Adjustment'}</Button>
                </DialogFooter>
            </form>
        </DialogContent>
    </Dialog>
);


function CashAndBank() {
    const { data, updateData, requestPasscode } = useData();
    const { cashInHand, banks, sales, purchases, expenses, payments, cashTransactions, customers, suppliers } = data;
    const { toast } = useToast();

    const [isBankDialogOpen, setIsBankDialogOpen] = useState(false);
    const [isCashDialogOpen, setIsCashDialogOpen] = useState(false);
    
    const [editingBank, setEditingBank] = useState(null);
    const [editingTx, setEditingTx] = useState(null);
    
    const [bankFormData, setBankFormData] = useState({ name: '', balance: '' });
    const [cashFormData, setCashFormData] = useState({ type: 'add', amount: '', description: '' });

    useEffect(() => {
        if (isBankDialogOpen && editingBank) {
            setBankFormData({ name: editingBank.name, balance: editingBank.balance.toString() });
        } else if (!isBankDialogOpen) {
            setEditingBank(null);
            setBankFormData({ name: '', balance: '' });
        }
    }, [isBankDialogOpen, editingBank]);

    useEffect(() => {
        if (isCashDialogOpen && editingTx) {
             setCashFormData({ 
                type: editingTx.ref.type, 
                amount: editingTx.ref.amount.toString(),
                description: editingTx.ref.description 
            });
        } else if (!isCashDialogOpen) {
            setEditingTx(null);
            setCashFormData({ type: 'add', amount: '', description: '' });
        }
    }, [isCashDialogOpen, editingTx]);

    const allTransactions = useMemo(() => {
        const txs = [];
        (sales || []).forEach(s => {
            if (s.paidAmount > 0) txs.push({
                id: `sale-${s.id}`, date: s.date, type: 'Sale',
                description: `Sale #${s.saleNumber} to ${customers.find(c=>c.id === s.customerId)?.name || ''}`,
                amount: s.paidAmount, flow: 'in', method: s.payment.method, bankId: s.payment.bankId,
                ref: s, refType: 'sale'
            });
        });
        (purchases || []).forEach(p => {
            if (p.paidAmount > 0) txs.push({
                id: `purchase-${p.id}`, date: p.date, type: 'Purchase',
                description: `Purchase #${p.purchaseNumber} from ${suppliers.find(sup=>sup.id === p.supplierId)?.name || ''}`,
                amount: p.paidAmount, flow: 'out', method: p.payment.method, bankId: p.payment.bankId,
                ref: p, refType: 'purchase'
            });
        });
        (expenses || []).forEach(e => {
            txs.push({
                id: `expense-${e.id}`, date: e.date, type: 'Expense',
                description: `Expense: ${e.category}`,
                amount: e.amount, flow: 'out', method: 'cash',
                ref: e, refType: 'expense'
            });
        });
        (payments || []).forEach(p => {
            const partyName = p.type === 'in' ? customers.find(c=>c.id === p.partyId)?.name : suppliers.find(sup=>sup.id === p.partyId)?.name;
            txs.push({
                id: `payment-${p.id}`, date: p.date, type: 'Payment',
                description: `Payment ${p.type === 'in' ? 'In' : 'Out'} - ${partyName || ''}`,
                amount: p.amount, flow: p.type, method: p.method, bankId: p.bankId,
                ref: p, refType: 'payment'
            });
        });
        (cashTransactions || []).forEach(ct => {
            txs.push({
                id: `cash-manual-${ct.id}`, date: ct.date, type: 'Manual',
                description: ct.description,
                amount: ct.amount, flow: ct.type === 'add' ? 'in' : 'out', method: 'cash',
                ref: ct, refType: 'cash'
            });
        });
        return txs.sort((a,b) => new Date(b.date) - new Date(a.date));
    }, [sales, purchases, expenses, payments, cashTransactions, customers, suppliers]);

    const cashLogTransactions = useMemo(() => allTransactions.filter(tx => tx.method === 'cash'), [allTransactions]);
    const bankLogTransactions = useMemo(() => allTransactions.filter(tx => tx.method === 'bank').map(tx => ({
        ...tx,
        bankName: banks.find(b => b.id === tx.bankId)?.name || 'Unknown Bank'
    })), [allTransactions, banks]);

    const handleBankSubmit = (e) => {
        e.preventDefault();
        requestPasscode(() => {
            if (!bankFormData.name || !bankFormData.balance) {
                toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
                return;
            }
            const bankData = {
                id: editingBank ? editingBank.id : Date.now().toString(),
                name: bankFormData.name,
                balance: parseFloat(bankFormData.balance)
            };
            let updatedBanks;
            if (editingBank) {
                updatedBanks = banks.map(b => b.id === editingBank.id ? bankData : b);
            } else {
                updatedBanks = [...banks, bankData];
            }
            updateData({ banks: updatedBanks });
            toast({ title: "Success", description: `Bank ${editingBank ? 'updated' : 'added'} successfully!` });
            setIsBankDialogOpen(false);
        });
    };
  
    const handleCashSubmit = (e) => {
        e.preventDefault();
        requestPasscode(() => {
            if (!cashFormData.amount || !cashFormData.description) {
                toast({ title: "Error", description: "Please fill all fields.", variant: "destructive" });
                return;
            }
            
            const amount = parseFloat(cashFormData.amount);
            
            if (editingTx) {
                const oldTx = editingTx.ref;
                const oldAmount = oldTx.amount;
                let revertedCash = cashInHand;
                if(oldTx.type === 'add') {
                    revertedCash -= oldAmount;
                } else {
                    revertedCash += oldAmount;
                }
                
                const newAmount = amount;
                let finalCash = revertedCash;
                if(cashFormData.type === 'add') {
                    finalCash += newAmount;
                } else {
                    finalCash -= newAmount;
                }

                const updatedTx = { ...oldTx, amount: newAmount, type: cashFormData.type, description: cashFormData.description };
                const updatedCashTransactions = cashTransactions.map(tx => tx.id === oldTx.id ? updatedTx : tx);
                updateData({ cashInHand: finalCash, cashTransactions: updatedCashTransactions });
                toast({ title: "Success", description: "Cash transaction updated successfully!" });

            } else {
                const newCashInHand = cashFormData.type === 'add' ? cashInHand + amount : cashInHand - amount;
                const newTransaction = { id: Date.now().toString(), date: new Date().toISOString(), type: cashFormData.type, amount, description: cashFormData.description };
                updateData({ cashInHand: newCashInHand, cashTransactions: [...(cashTransactions || []), newTransaction] });
                toast({ title: "Success", description: "Cash in hand adjusted successfully!" });
            }
           
            setIsCashDialogOpen(false);
        });
    };

    const handleEditBank = (bank) => {
        setEditingBank(bank);
        setIsBankDialogOpen(true);
    };

    const handleEditTransaction = (tx) => {
        setEditingTx(tx);
        if (tx.method === 'cash') {
            setIsCashDialogOpen(true);
        } else {
            toast({ title: "Info", description: "Editing for non-manual bank transactions is not yet supported from this screen.", variant: "default" });
        }
    }
  
    const handleDeleteBank = (id) => {
        requestPasscode(() => {
            const isBankUsed = allTransactions.some(tx => tx.method === 'bank' && tx.bankId === id);
            if(isBankUsed) {
                toast({ title: "Deletion Failed", description: "This bank account has transactions linked to it and cannot be deleted.", variant: "destructive" });
                return;
            }
            updateData({ banks: banks.filter(b => b.id !== id) });
            toast({ title: "Success", description: "Bank deleted successfully!" });
        });
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold gradient-text">Cash & Bank</h1>
                <p className="text-gray-500 dark:text-gray-400 mt-1">Manage your cash flow and bank accounts.</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <CashInHandCard cashInHand={cashInHand} onAdjust={() => setIsCashDialogOpen(true)} />
                <BankAccountsCard banks={banks} onAdd={() => setIsBankDialogOpen(true)} onEdit={handleEditBank} onDelete={handleDeleteBank} />
            </div>

            <BankDialog 
                isOpen={isBankDialogOpen}
                onOpenChange={setIsBankDialogOpen}
                onSubmit={handleBankSubmit}
                editingBank={editingBank}
                formData={bankFormData}
                setFormData={setBankFormData}
            />
            <CashDialog 
                isOpen={isCashDialogOpen}
                onOpenChange={setIsCashDialogOpen}
                onSubmit={handleCashSubmit}
                editingTx={editingTx}
                formData={cashFormData}
                setFormData={setCashFormData}
            />

            <Tabs defaultValue="cash" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="cash"><Wallet className="h-4 w-4 mr-2"/>Cash Log</TabsTrigger>
                    <TabsTrigger value="bank"><Landmark className="h-4 w-4 mr-2"/>Bank Log</TabsTrigger>
                </TabsList>
                <TabsContent value="cash">
                    <TransactionLog
                        transactions={cashLogTransactions}
                        title="Cash Transactions Log"
                        icon={<Wallet className="h-6 w-6 mr-2 text-green-500"/>}
                        onEdit={handleEditTransaction}
                    />
                </TabsContent>
                <TabsContent value="bank">
                     <TransactionLog
                        transactions={bankLogTransactions}
                        title="Bank Transactions Log"
                        icon={<Landmark className="h-6 w-6 mr-2 text-blue-500"/>}
                        onEdit={handleEditTransaction}
                    />
                </TabsContent>
            </Tabs>
        </div>
    );
}

export default CashAndBank;
