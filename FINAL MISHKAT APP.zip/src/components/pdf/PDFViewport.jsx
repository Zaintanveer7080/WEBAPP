import React from 'react';

export function PDFViewport() {
  return <div id="pdf-viewport" style={{ position: 'fixed', left: '-10000px', top: 0 }} />;
}