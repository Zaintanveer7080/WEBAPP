
import React, { useState, useEffect, useMemo } from 'react';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Trash2, Plus, PackagePlus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const PurchaseForm = ({ purchase, onClose }) => {
  const { data, updateData } = useData();
  const { suppliers, items, banks, cashInHand, purchases, payments } = data;
  const { toast } = useToast();

  const [purchaseNumber, setPurchaseNumber] = useState('');
  const [supplierId, setSupplierId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [purchaseItems, setPurchaseItems] = useState([]);
  const [notes, setNotes] = useState('');

  const [discount, setDiscount] = useState('');
  const [discountType, setDiscountType] = useState('flat');
  
  const [paymentMethod, setPaymentMethod] = useState('cash');
  const [paidAmount, setPaidAmount] = useState('');
  const [bankId, setBankId] = useState('');
  const [paymentRef, setPaymentRef] = useState('');
  
  const [isAddItemDialogOpen, setIsAddItemDialogOpen] = useState(false);
  const [newItemData, setNewItemData] = useState({ sku: '', name: '', purchasePrice: '', unit: 'pcs' });

  const generatePurchaseNumber = () => {
    const validPurchases = (purchases || [])
      .filter(p => p && p.purchaseNumber && typeof p.purchaseNumber === 'string' && p.purchaseNumber.startsWith('P-'))
      .map(p => parseInt(p.purchaseNumber.split('-')[1] || '0', 10))
      .sort((a, b) => a - b);
      
    if (validPurchases.length === 0) {
      return 'P-0001';
    }

    const lastNum = validPurchases[validPurchases.length - 1];
    return `P-${(lastNum + 1).toString().padStart(4, '0')}`;
  };

  useEffect(() => {
    if (purchase) {
      setPurchaseNumber(purchase.purchaseNumber);
      setSupplierId(purchase.supplierId);
      setDate(purchase.date);
      setPurchaseItems(purchase.items || []);
      setNotes(purchase.notes || '');
      setDiscount(purchase.discount?.value || '');
      setDiscountType(purchase.discount?.type || 'flat');
      setPaymentMethod(purchase.payment?.method || 'cash');
      setPaidAmount(purchase.paidAmount?.toString() || '');
      setBankId(purchase.payment?.bankId || '');
      setPaymentRef(purchase.payment?.ref || '');
    } else {
      setPurchaseNumber(generatePurchaseNumber());
      setDate(new Date().toISOString().split('T')[0]);
      setPurchaseItems([{ itemId: '', quantity: 1, price: 0 }]);
    }
  }, [purchase]);

  const calculateTotals = () => {
    const currentItems = purchaseItems || [];
    const subTotal = currentItems.reduce((sum, item) => sum + ((item.quantity || 0) * (item.price || 0)), 0);
    let totalDiscount = discountType === 'flat' ? (parseFloat(discount) || 0) : subTotal * (parseFloat(discount) || 0) / 100;
    const totalCost = subTotal - totalDiscount;
    const totalQuantity = currentItems.reduce((sum, item) => sum + (parseInt(item.quantity) || 0), 0);
    const balance = totalCost - (parseFloat(paidAmount) || 0);

    const firstItem = currentItems.length > 0 ? items.find(i => i.id === currentItems[0].itemId) : null;
    const unit = firstItem ? firstItem.unit : '';

    return { subTotal, totalDiscount, totalCost, totalQuantity, balance, unit };
  };

  const { subTotal, totalDiscount, totalCost, totalQuantity, balance, unit } = useMemo(() => calculateTotals(), [purchaseItems, discount, discountType, paidAmount, items]);

  useEffect(() => {
    if (!purchase) {
      setPaidAmount(totalCost.toFixed(2));
    }
  }, [totalCost, purchase]);


  const handleItemChange = (index, field, value) => {
    const updatedItems = [...purchaseItems];
    updatedItems[index][field] = value;
    if (field === 'itemId') {
      const selectedItem = items.find(i => i.id === value);
      if (selectedItem) {
        updatedItems[index]['price'] = selectedItem.purchasePrice || 0;
      }
    }
    setPurchaseItems(updatedItems);
  };

  const addItem = () => {
    setPurchaseItems([...(purchaseItems || []), { itemId: '', quantity: 1, price: 0 }]);
  };

  const removeItem = (index) => {
    const updatedItems = (purchaseItems || []).filter((_, i) => i !== index);
    setPurchaseItems(updatedItems);
  };

  const handleAddNewItem = (e) => {
    e.preventDefault();
    if (!newItemData.sku || !newItemData.name) {
      toast({ title: 'Error', description: 'SKU and Name are required for new item.', variant: 'destructive' });
      return;
    }
    if (items.some(i => i.sku.toLowerCase() === newItemData.sku.toLowerCase())) {
      toast({ title: 'Error', description: 'This SKU already exists.', variant: 'destructive' });
      return;
    }
    const newItem = {
      id: Date.now().toString(),
      sku: newItemData.sku,
      name: newItemData.name,
      purchasePrice: parseFloat(newItemData.purchasePrice) || 0,
      salePrice: 0,
      openingStock: 0,
      category: '',
      unit: newItemData.unit || 'pcs'
    };
    updateData({ items: [...items, newItem] });
    toast({ title: 'Success', description: `Item "${newItem.name}" added.` });
    setIsAddItemDialogOpen(false);
    setNewItemData({ sku: '', name: '', purchasePrice: '', unit: 'pcs' });
    setPurchaseItems([...(purchaseItems || []), { itemId: newItem.id, quantity: 1, price: newItem.purchasePrice }]);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!supplierId || (purchaseItems || []).some(i => !i.itemId)) {
      toast({ title: 'Error', description: 'Supplier and all items must be selected.', variant: 'destructive' });
      return;
    }
    if ((purchases || []).some(p => p.purchaseNumber === purchaseNumber && p.id !== purchase?.id)) {
      toast({ title: 'Error', description: 'Purchase number must be unique.', variant: 'destructive' });
      return;
    }

    const enteredPaidAmount = parseFloat(paidAmount) || 0;
    
    const purchaseId = purchase ? purchase.id : Date.now().toString();

    const purchaseData = {
      id: purchaseId,
      purchaseNumber,
      supplierId,
      date,
      items: (purchaseItems || []).map(i => ({...i, quantity: parseInt(i.quantity) || 0, price: parseFloat(i.price) || 0})),
      notes,
      subTotal,
      totalQuantity,
      discount: { value: parseFloat(discount) || 0, type: discountType },
      totalCost: totalCost,
      paidAmount: enteredPaidAmount,
      payment: {
        method: paymentMethod,
        bankId,
        ref: paymentRef,
      }
    };
    
    const newPayments = [];
    const oldPayment = purchase ? (payments || []).find(p => p.invoiceId === purchase.id) : null;
    const oldPaymentAmount = oldPayment?.amount || 0;

    if (enteredPaidAmount > 0) {
        newPayments.push({
            id: oldPayment?.id || Date.now().toString() + Math.random(),
            partyId: supplierId,
            partyType: 'supplier',
            type: 'out',
            invoiceId: purchaseId,
            amount: enteredPaidAmount,
            date: date,
            method: paymentMethod,
            bankId: paymentMethod === 'bank' ? bankId : undefined,
            notes: `Payment for Purchase #${purchaseNumber}`
        });
    }

    let updatedCashInHand = cashInHand;
    let updatedBanks = JSON.parse(JSON.stringify(banks || []));

    if (oldPayment) {
        if(oldPayment.method === 'cash') {
            updatedCashInHand += oldPaymentAmount;
        } else if (oldPayment.bankId) {
            const oldBankIndex = updatedBanks.findIndex(b => b.id === oldPayment.bankId);
            if(oldBankIndex > -1) updatedBanks[oldBankIndex].balance += oldPaymentAmount;
        }
    }

    if (enteredPaidAmount > 0) {
        if (paymentMethod === 'cash') {
            updatedCashInHand -= enteredPaidAmount;
        } else if (bankId) {
            const newBankIndex = updatedBanks.findIndex(b => b.id === bankId);
            if(newBankIndex > -1) updatedBanks[newBankIndex].balance -= enteredPaidAmount;
        }
    }

    const otherPayments = (payments || []).filter(p => p.invoiceId !== purchaseId);
    const updatedPayments = [...otherPayments, ...newPayments];
    const newPurchases = purchase 
      ? (purchases || []).map(p => p.id === purchase.id ? purchaseData : p)
      : [...(purchases || []), purchaseData];

    updateData({ purchases: newPurchases, banks: updatedBanks, cashInHand: updatedCashInHand, payments: updatedPayments });
    toast({ title: 'Success', description: `Purchase ${purchase ? 'updated' : 'saved'}.` });
    onClose();
  };


  return (
    <div className="flex flex-col h-full">
      <form onSubmit={handleSubmit} className="flex-1 flex flex-col">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="purchaseNumber">Purchase Number</Label>
              <Input id="purchaseNumber" value={purchaseNumber} onChange={e => setPurchaseNumber(e.target.value)} />
            </div>
            <div>
              <Label htmlFor="supplier">Supplier</Label>
              <Select value={supplierId} onValueChange={setSupplierId}>
                <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
                <SelectContent>{(suppliers || []).map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" value={date} onChange={e => setDate(e.target.value)} />
            </div>
          </div>
          
          <div className="space-y-2 border-t border-b py-4">
            <Label>Items</Label>
            {(purchaseItems || []).map((item, index) => (
              <div key={index} className="flex items-end gap-2">
                <div className="flex-grow">
                  <Select value={item.itemId} onValueChange={v => handleItemChange(index, 'itemId', v)}>
                    <SelectTrigger><SelectValue placeholder="Select item" /></SelectTrigger>
                    <SelectContent>
                      {(items || []).map(i => <SelectItem key={i.id} value={i.id}>{i.name} ({i.sku})</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="w-24"><Input type="number" placeholder="Qty" value={item.quantity} onChange={e => handleItemChange(index, 'quantity', e.target.value)} /></div>
                <div className="w-32"><Input type="number" placeholder="Price" value={item.price} onChange={e => handleItemChange(index, 'price', e.target.value)} /></div>
                <div><Button type="button" variant="destructive" size="icon" onClick={() => removeItem(index)}><Trash2 className="h-4 w-4" /></Button></div>
              </div>
            ))}
            <div className="flex gap-2 pt-2">
                <Button type="button" variant="outline" onClick={addItem}><Plus className="h-4 w-4 mr-2"/>Add Item</Button>
                <Dialog open={isAddItemDialogOpen} onOpenChange={setIsAddItemDialogOpen}>
                    <DialogTrigger asChild><Button type="button" variant="secondary"><PackagePlus className="h-4 w-4 mr-2"/>Create New Item</Button></DialogTrigger>
                    <DialogContent>
                        <DialogHeader><DialogTitle>Create New Item</DialogTitle></DialogHeader>
                        <form onSubmit={handleAddNewItem} className="py-4 space-y-4">
                            <div><Label htmlFor="newItemSku">SKU</Label><Input id="newItemSku" value={newItemData.sku} onChange={e => setNewItemData({...newItemData, sku: e.target.value})} /></div>
                            <div><Label htmlFor="newItemName">Name</Label><Input id="newItemName" value={newItemData.name} onChange={e => setNewItemData({...newItemData, name: e.target.value})} /></div>
                            <div><Label htmlFor="newItemPrice">Purchase Price</Label><Input id="newItemPrice" type="number" value={newItemData.purchasePrice} onChange={e => setNewItemData({...newItemData, purchasePrice: e.target.value})} /></div>
                            <div><Label htmlFor="newItemUnit">Unit</Label><Input id="newItemUnit" value={newItemData.unit} onChange={e => setNewItemData({...newItemData, unit: e.target.value})} /></div>
                            <DialogFooter>
                              <Button type="button" variant="outline" onClick={() => setIsAddItemDialogOpen(false)}>Cancel</Button>
                              <Button type="submit">Create and Add</Button>
                            </DialogFooter>
                        </form>
                    </DialogContent>
                </Dialog>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label>Payment</Label>
                <div className="grid grid-cols-2 gap-2">
                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                        <SelectTrigger><SelectValue/></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="cash">Cash</SelectItem>
                            <SelectItem value="bank">Bank</SelectItem>
                        </SelectContent>
                    </Select>
                    {paymentMethod === 'bank' && (
                         <Select value={bankId} onValueChange={setBankId}>
                            <SelectTrigger><SelectValue placeholder="Select bank"/></SelectTrigger>
                            <SelectContent>{(banks || []).map(b => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}</SelectContent>
                        </Select>
                    )}
                </div>
                 {paymentMethod === 'bank' && <Input className="mt-2" placeholder="Bank Reference No." value={paymentRef} onChange={e => setPaymentRef(e.target.value)} />}
                 <div className="mt-2"><Label htmlFor="paidAmount">Paid Amount</Label><Input id="paidAmount" type="number" value={paidAmount} onChange={e => setPaidAmount(e.target.value)} /></div>
              </div>
              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea id="notes" value={notes} onChange={e => setNotes(e.target.value)} />
              </div>
            </div>
            <div className="bg-muted p-4 rounded-lg space-y-2">
                <div className="flex justify-between items-center text-sm"><span>Total Quantity</span><span>{totalQuantity} {unit}</span></div>
                <div className="flex justify-between items-center text-sm"><span>Subtotal</span><span>RS {subTotal.toFixed(2)}</span></div>
                <div className="flex justify-between items-center text-sm"><span className="text-sm">Discount</span>
                  <div className="flex gap-1">
                    <Input type="number" value={discount} onChange={e => setDiscount(e.target.value)} className="h-8 w-20"/>
                    <Select value={discountType} onValueChange={setDiscountType}>
                        <SelectTrigger className="h-8 w-24"><SelectValue/></SelectTrigger>
                        <SelectContent>
                            <SelectItem value="flat">Flat</SelectItem>
                            <SelectItem value="percent">%</SelectItem>
                        </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="flex justify-between items-center font-bold text-lg border-t pt-2"><span>Total</span><span>RS {totalCost.toFixed(2)}</span></div>
                <div className="flex justify-between items-center text-sm"><span>Paid</span><span>RS {(parseFloat(paidAmount) || 0).toFixed(2)}</span></div>
                <div className="flex justify-between items-center text-sm font-semibold"><span>Balance</span><span>RS {balance.toFixed(2)}</span></div>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-2 p-4 border-t bg-background sticky bottom-0">
          <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="submit">{purchase ? 'Update' : 'Save'} Purchase</Button>
        </div>
      </form>
    </div>
  );
};

export default PurchaseForm;
