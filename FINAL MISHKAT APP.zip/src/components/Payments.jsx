import React, { useState, useMemo } from 'react';
import { useData } from '@/contexts/DataContext';
import { Button } from '@/components/ui/button';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger, AlertDialogFooter } from '@/components/ui/alert-dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { Plus, ArrowLeftRight, User, Building, Hand, Landmark, Edit, Trash2, Eye } from 'lucide-react';
import PaymentForm from '@/components/payments/PaymentForm';

function Payments() {
  const { data, updateData, requestPasscode, setTransactionToView } = useData();
  const { customers, suppliers, payments, banks, cashInHand, cashTransactions } = data;
  const { toast } = useToast();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [paymentType, setPaymentType] = useState('in'); // 'in' or 'out'
  const [editingPayment, setEditingPayment] = useState(null);

  const getPartyName = (type, id) => {
    if (type === 'in') return customers.find(c => c.id === id)?.name || 'Unknown';
    return suppliers.find(s => s.id === id)?.name || 'Unknown';
  };
  
  const paymentHistory = useMemo(() => {
    return [...payments].sort((a,b) => new Date(b.date) - new Date(a.date));
  }, [payments]);

  const handleEdit = (payment) => {
    setPaymentType(payment.type);
    setEditingPayment(payment);
    setIsDialogOpen(true);
  };

  const handleDelete = (paymentToDelete) => {
    requestPasscode(() => {
      // Reverse financial impact
      let updatedCashInHand = cashInHand;
      let updatedBanks = JSON.parse(JSON.stringify(banks));
      
      if (paymentToDelete.method === 'cash') {
        if (paymentToDelete.type === 'in') updatedCashInHand -= paymentToDelete.amount;
        else updatedCashInHand += paymentToDelete.amount;
      } else {
        const bankIndex = updatedBanks.findIndex(b => b.id === paymentToDelete.bankId);
        if (bankIndex !== -1) {
          if (paymentToDelete.type === 'in') updatedBanks[bankIndex].balance -= paymentToDelete.amount;
          else updatedBanks[bankIndex].balance += paymentToDelete.amount;
        }
      }

      // Remove payment record
      const updatedPayments = payments.filter(p => p.id !== paymentToDelete.id);
      
      // Attempt to find and remove related cash transaction (best effort)
      const partyName = getPartyName(paymentToDelete.type, paymentToDelete.partyId);
      const expectedDescription = `Payment ${paymentToDelete.type === 'in' ? 'from' : 'to'} ${partyName}`;
      const updatedCashTransactions = cashTransactions.filter(ct => 
        !(ct.amount === paymentToDelete.amount && ct.description === expectedDescription)
      );

      updateData({
        payments: updatedPayments,
        cashInHand: updatedCashInHand,
        banks: updatedBanks,
        cashTransactions: updatedCashTransactions,
      });

      toast({ title: "Success", description: "Payment deleted successfully." });
    });
  };

  const openNewPaymentDialog = (type) => {
    setPaymentType(type);
    setEditingPayment(null);
    setIsDialogOpen(true);
  };

  return (
    <div className="space-y-6">
       <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold gradient-text">Payments</h1>
          <p className="text-gray-500 dark:text-gray-400 mt-1">Manage incoming and outgoing payments with advanced allocation.</p>
        </div>
        <div className="flex gap-2">
           <Button onClick={() => openNewPaymentDialog('in')} className="bg-green-600 hover:bg-green-700">
             <Plus className="h-4 w-4 mr-2" /> Payment In
           </Button>
           <Button onClick={() => openNewPaymentDialog('out')} className="bg-red-600 hover:bg-red-700">
             <Plus className="h-4 w-4 mr-2" /> Payment Out
           </Button>
        </div>
      </div>
      
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{editingPayment ? 'Edit' : 'Record'} Payment {paymentType === 'in' ? 'In' : 'Out'}</DialogTitle>
          </DialogHeader>
          <PaymentForm 
            paymentType={paymentType} 
            onClose={() => setIsDialogOpen(false)}
            paymentToEdit={editingPayment}
          />
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center"><ArrowLeftRight className="h-5 w-5 mr-2" /> Payment History</CardTitle>
        </CardHeader>
        <CardContent>
           {paymentHistory.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No payments recorded yet.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Date</th>
                    <th className="text-left p-2">Type</th>
                    <th className="text-left p-2">Party</th>
                    <th className="text-left p-2">Amount</th>
                    <th className="text-left p-2">Method</th>
                    <th className="text-left p-2">Discount</th>
                    <th className="text-right p-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {paymentHistory.map(p => (
                    <tr key={p.id} className="border-b">
                      <td className="p-2">{new Date(p.date).toLocaleDateString()}</td>
                      <td className="p-2">
                        <span className={`font-semibold ${p.type === 'in' ? 'text-green-600' : 'text-red-600'}`}>
                          {p.type === 'in' ? 'Payment In' : 'Payment Out'}
                        </span>
                      </td>
                      <td className="p-2 flex items-center gap-2">
                        {p.type === 'in' ? <User className="h-4 w-4 text-gray-500" /> : <Building className="h-4 w-4 text-gray-500" />}
                        {getPartyName(p.type, p.partyId)}
                      </td>
                      <td className="p-2 font-bold">RS {p.amount.toFixed(2)}</td>
                      <td className="p-2 flex items-center gap-2">
                        {p.method === 'cash' ? <Hand className="h-4 w-4 text-gray-500" /> : <Landmark className="h-4 w-4 text-gray-500" />}
                        {p.method === 'cash' ? 'Cash' : banks.find(b => b.id === p.bankId)?.name || 'Bank'}
                      </td>
                      <td className="p-2 font-semibold text-blue-600">
                        RS {(p.discount || 0).toFixed(2)}
                      </td>
                      <td className="p-2 text-right">
                        <div className="flex gap-2 justify-end">
                          <Button variant="ghost" size="icon" onClick={() => setTransactionToView({ transaction: p, type: 'payment' })}><Eye className="h-4 w-4 text-purple-500" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(p)}><Edit className="h-4 w-4" /></Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-600"><Trash2 className="h-4 w-4" /></Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This action cannot be undone. This will permanently delete the payment record and reverse its financial impact.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction onClick={() => handleDelete(p)}>Continue</AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default Payments;