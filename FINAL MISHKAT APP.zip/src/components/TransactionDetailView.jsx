import React, { useCallback } from 'react';
import { useData } from '@/contexts/DataContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { FileDown, X, ShoppingCart, TrendingUp, TrendingDown, CreditCard, ArrowLeftRight, ArrowUpRight, ArrowDownRight, User, Building, Landmark, Hand } from 'lucide-react';
import { generatePdf } from '@/components/pdf/PdfGenerator';
import SaleInvoiceTemplate from '@/components/pdf/SaleInvoiceTemplate';
import PurchaseInvoiceTemplate from '@/components/pdf/PurchaseInvoiceTemplate';
import ExpenseVoucherTemplate from '@/components/pdf/ExpenseVoucherTemplate';

const TransactionDetailView = ({ transaction, type, onClose }) => {
  const { data, getInvoiceStatus } = useData();
  const { items, customers, suppliers, banks, payments, purchases } = data;

  const handleDownloadPdf = () => {
    switch (type) {
      case 'sale':
        const saleCustomer = customers.find(c => c.id === transaction.customerId);
        generatePdf(<SaleInvoiceTemplate sale={transaction} customer={saleCustomer} items={items} settings={data.settings} getInvoiceStatus={getInvoiceStatus} />, `Sale-Invoice-${transaction.saleNumber}.pdf`);
        break;
      case 'purchase':
        const purchaseSupplier = suppliers.find(s => s.id === transaction.supplierId);
        generatePdf(<PurchaseInvoiceTemplate purchase={transaction} supplier={purchaseSupplier} items={items} settings={data.settings} getInvoiceStatus={getInvoiceStatus} />, `Purchase-Invoice-${transaction.purchaseNumber}.pdf`);
        break;
      case 'expense':
        generatePdf(<ExpenseVoucherTemplate expense={transaction} settings={data.settings} />, `Expense-Voucher-${transaction.id}.pdf`);
        break;
      default:
        break;
    }
  };
  
  const getStatusBadge = (status) => {
    const statusStyles = {
      Paid: 'bg-green-100 text-green-800',
      Partial: 'bg-orange-100 text-orange-800',
      Credit: 'bg-red-100 text-red-800',
    };
    return <Badge className={`${statusStyles[status]} text-xs`}>{status}</Badge>;
  };

  const getPurchaseCostForItem = useCallback((itemId) => {
    const allPurchasesForItem = (purchases || [])
      .flatMap(p => p.items.map(item => ({ ...item, date: p.date })))
      .filter(item => item.itemId === itemId)
      .sort((a, b) => new Date(b.date) - new Date(a.date));

    if (allPurchasesForItem.length > 0) {
      return allPurchasesForItem[0].price;
    }
    
    const itemMaster = items.find(i => i.id === itemId);
    return itemMaster?.purchasePrice || 0;
  }, [purchases, items]);

  const renderDetails = () => {
    switch (type) {
      case 'sale':
      case 'purchase':
        const isSale = type === 'sale';
        const party = isSale 
          ? customers.find(c => c.id === transaction.customerId)
          : suppliers.find(s => s.id === transaction.supplierId);
        const { status, paidAmount, balance } = getInvoiceStatus(transaction);
        const relatedPayments = (payments || []).filter(p => p.invoiceId === transaction.id);
        
        const itemsCost = isSale ? (transaction.items || []).reduce((cost, saleItem) => {
          const purchasePrice = getPurchaseCostForItem(saleItem.itemId);
          return cost + (purchasePrice * (saleItem.quantity || 0));
        }, 0) : 0;
        const profit = isSale ? (transaction.totalCost || 0) - itemsCost : 0;

        return (
          <>
            <div className="grid grid-cols-3 gap-4 mb-4 text-sm">
                <div><strong>{isSale ? 'Invoice #' : 'Purchase #'}:</strong> {transaction.saleNumber || transaction.purchaseNumber}</div>
                <div><strong>Date:</strong> {new Date(transaction.date).toLocaleDateString()}</div>
                <div className="flex justify-end">{getStatusBadge(status)}</div>
            </div>
             <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                <div>
                    <h4 className="font-semibold text-muted-foreground mb-1">{isSale ? 'Customer' : 'Supplier'}</h4>
                    <p className="font-bold">{party?.name}</p>
                    <p>{party?.contact}</p>
                    <p>{party?.address}</p>
                </div>
                <div className="text-right">
                     <h4 className="font-semibold text-muted-foreground mb-1">Created By</h4>
                     <p>Admin</p>
                     <p>{new Date(transaction.date).toLocaleString()}</p>
                </div>
            </div>
            
            <Card>
              <CardHeader><CardTitle>Items</CardTitle></CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Item</TableHead>
                      <TableHead className="text-right">Quantity</TableHead>
                      <TableHead className="text-right">Price</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(transaction.items || []).map((item, index) => {
                        const itemDetails = items.find(i => i.id === item.itemId);
                        return (
                          <TableRow key={`${item.itemId}-${index}`}>
                            <TableCell>{itemDetails?.name || 'N/A'}</TableCell>
                            <TableCell className="text-right">{item.quantity} {itemDetails?.unit}</TableCell>
                            <TableCell className="text-right">RS {item.price.toFixed(2)}</TableCell>
                            <TableCell className="text-right">RS {(item.quantity * item.price).toFixed(2)}</TableCell>
                          </TableRow>
                        )
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
            
             <div className="grid grid-cols-2 gap-8 mt-4">
                 <div>
                    {relatedPayments.length > 0 && (
                        <Card>
                            <CardHeader><CardTitle>Payment History</CardTitle></CardHeader>
                            <CardContent>
                                <Table>
                                    <TableHeader><TableRow><TableHead>Date</TableHead><TableHead className="text-right">Amount</TableHead></TableRow></TableHeader>
                                    <TableBody>
                                        {relatedPayments.map(p => (
                                            <TableRow key={p.id}>
                                                <TableCell>{new Date(p.date).toLocaleDateString()}</TableCell>
                                                <TableCell className="text-right">RS {p.amount.toFixed(2)}</TableCell>
                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </CardContent>
                        </Card>
                    )}
                 </div>
                 <div className="space-y-2 text-sm">
                    <div className="flex justify-between"><span>Subtotal</span><span>RS {(transaction.subTotal || 0).toFixed(2)}</span></div>
                    {transaction.discount?.value > 0 && <div className="flex justify-between"><span>Discount</span><span>- RS {((transaction.subTotal || 0) - (transaction.totalCost || 0)).toFixed(2)}</span></div>}
                    <div className="flex justify-between font-bold text-base border-y py-2"><span>Total</span><span>RS {(transaction.totalCost || 0).toFixed(2)}</span></div>
                    <div className="flex justify-between"><span>Paid</span><span>RS {paidAmount.toFixed(2)}</span></div>
                    <div className="flex justify-between font-semibold"><span>Balance Due</span><span>RS {balance.toFixed(2)}</span></div>
                    {isSale && (
                      <div className={`flex justify-between items-center font-bold pt-2 mt-2 border-t ${profit >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                          <span>Profit</span>
                          <span className="flex items-center gap-1">
                            {profit >= 0 ? <TrendingUp className="h-4 w-4"/> : <TrendingDown className="h-4 w-4"/>}
                            RS {profit.toFixed(2)}
                          </span>
                      </div>
                    )}
                 </div>
            </div>
            {transaction.notes && <p className="mt-4 text-sm text-muted-foreground"><strong>Notes:</strong> {transaction.notes}</p>}
          </>
        );
      case 'expense':
        return (
          <>
            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                <div><strong>Voucher ID:</strong> {transaction.id}</div>
                <div className="text-right"><strong>Date:</strong> {new Date(transaction.date).toLocaleDateString()}</div>
            </div>
            <Card>
                <CardHeader>
                    <CardTitle className="flex justify-between items-center">
                        <span>{transaction.category}</span>
                        <span className="text-2xl font-bold text-red-600">RS {transaction.amount.toFixed(2)}</span>
                    </CardTitle>
                </CardHeader>
                <CardContent>
                    <p className="text-muted-foreground">{transaction.notes || 'No notes for this expense.'}</p>
                </CardContent>
            </Card>
          </>
        );
      case 'payment':
        const partyName = transaction.type === 'in'
            ? customers.find(c => c.id === transaction.partyId)?.name
            : suppliers.find(s => s.id === transaction.partyId)?.name;
        const paymentIcon = transaction.type === 'in' ? <User className="h-4 w-4 mr-2"/> : <Building className="h-4 w-4 mr-2"/>;
        const methodIcon = transaction.method === 'cash' ? <Hand className="h-4 w-4 mr-2"/> : <Landmark className="h-4 w-4 mr-2"/>;
        const bankName = transaction.method === 'bank' ? banks.find(b => b.id === transaction.bankId)?.name : 'Cash';
        
        return (
            <>
                <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div><strong>Payment ID:</strong> {transaction.id}</div>
                    <div className="text-right"><strong>Date:</strong> {new Date(transaction.date).toLocaleDateString()}</div>
                </div>
                 <Card>
                    <CardHeader>
                        <CardTitle className={`flex justify-between items-center ${transaction.type === 'in' ? 'text-green-600' : 'text-red-600'}`}>
                            <span>{transaction.type === 'in' ? 'Payment In' : 'Payment Out'}</span>
                            <span className="text-2xl font-bold">RS {transaction.amount.toFixed(2)}</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex items-center"><User className="h-4 w-4 mr-2 text-muted-foreground"/> <strong>Party:</strong> <span className="ml-2">{partyName || 'N/A'}</span></div>
                        <div className="flex items-center">{methodIcon} <strong>Method:</strong> <span className="ml-2">{bankName}</span></div>
                        {transaction.discount > 0 && <div><strong>Discount:</strong> <span className="ml-2">RS {transaction.discount.toFixed(2)}</span></div>}
                        {transaction.invoiceId && <div><strong>Invoice Ref:</strong> <span className="ml-2">{transaction.invoiceId}</span></div>}
                        {transaction.notes && <p className="text-muted-foreground pt-2 border-t"><strong>Notes:</strong> {transaction.notes}</p>}
                    </CardContent>
                </Card>
            </>
        );
      case 'cash':
        const cashIcon = transaction.type === 'add' ? <ArrowUpRight className="h-6 w-6 text-green-500"/> : <ArrowDownRight className="h-6 w-6 text-red-500"/>
        return (
             <>
                <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div><strong>Transaction ID:</strong> {transaction.id}</div>
                    <div className="text-right"><strong>Date:</strong> {new Date(transaction.date).toLocaleString()}</div>
                </div>
                 <Card>
                    <CardHeader>
                        <CardTitle className={`flex justify-between items-center ${transaction.type === 'add' ? 'text-green-600' : 'text-red-600'}`}>
                            <div className="flex items-center">{cashIcon} <span className="ml-2">Cash {transaction.type === 'add' ? 'Added' : 'Removed'}</span></div>
                            <span className="text-2xl font-bold">RS {transaction.amount.toFixed(2)}</span>
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <p className="text-muted-foreground">{transaction.description}</p>
                    </CardContent>
                </Card>
            </>
        );
      default:
        return <p>Unsupported transaction type.</p>;
    }
  };
  
  const getTitle = () => {
      switch(type) {
          case 'sale': return { title: 'Sale Details', icon: <TrendingUp className="h-5 w-5 mr-2" /> };
          case 'purchase': return { title: 'Purchase Details', icon: <ShoppingCart className="h-5 w-5 mr-2" /> };
          case 'expense': return { title: 'Expense Details', icon: <CreditCard className="h-5 w-5 mr-2" /> };
          case 'payment': return { title: 'Payment Details', icon: <ArrowLeftRight className="h-5 w-5 mr-2" /> };
          case 'cash': return { title: 'Cash Transaction', icon: <ArrowLeftRight className="h-5 w-5 mr-2" /> };
          default: return { title: 'Transaction Details', icon: null };
      }
  }

  const { title, icon } = getTitle();

  return (
    <Dialog open={true} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center">{icon} {title}</DialogTitle>
        </DialogHeader>
        <div className="py-4 max-h-[70vh] overflow-y-auto pr-2">
            {renderDetails()}
        </div>
        <DialogFooter>
          {(type === 'sale' || type === 'purchase' || type === 'expense') && (
            <Button variant="outline" onClick={handleDownloadPdf}>
              <FileDown className="mr-2 h-4 w-4" /> Download PDF
            </Button>
          )}
          <Button variant="outline" onClick={onClose}><X className="mr-2 h-4 w-4" /> Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default TransactionDetailView;