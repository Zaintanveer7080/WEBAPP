
import React, { useState, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import Sidebar from '@/components/Sidebar.jsx';
import Dashboard from '@/components/Dashboard.jsx';
import { Purchase } from '@/components/Purchase.jsx';
import Sales from '@/components/Sales.jsx';
import Expenses from '@/components/Expenses.jsx';
import Suppliers from '@/components/Suppliers.jsx';
import Customers from '@/components/Customers.jsx';
import Items from '@/components/Items.jsx';
import Reports from '@/components/reports/Reports.jsx';
import Payments from '@/components/Payments.jsx';
import CashAndBank from '@/components/CashAndBank.jsx';
import OnlineOrders from '@/components/OnlineOrders.jsx';
import Settings from '@/components/Settings.jsx';
import { Toaster } from '@/components/ui/toaster';
import { DataProvider, useData } from '@/contexts/DataContext.jsx';
import { PDFViewport } from '@/components/pdf/PDFViewport';
import TransactionDetailView from '@/components/TransactionDetailView.jsx';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import Auth from '@/components/auth/Auth';

function AppContent() {
  const [activeModule, setActiveModule] = useState('dashboard');
  const { data, transactionToView, setTransactionToView, loading: dataLoading } = useData();
  const companyName = data?.settings?.companyName || 'ERP System';
  
  const renderActiveModule = useCallback(() => {
    switch (activeModule) {
      case 'dashboard':
        return <Dashboard />;
      case 'purchase':
        return <Purchase />;
      case 'sales':
        return <Sales />;
      case 'onlineOrders':
        return <OnlineOrders />;
      case 'expenses':
        return <Expenses />;
      case 'suppliers':
        return <Suppliers />;
      case 'customers':
        return <Customers />;
      case 'items':
        return <Items />;
      case 'reports':
        return <Reports />;
      case 'payments':
        return <Payments />;
      case 'cashAndBank':
        return <CashAndBank />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  }, [activeModule]);

  if (dataLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-2xl font-semibold text-foreground">Loading Your Data...</div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{companyName} - Inventory, Billing & Reporting</title>
        <meta name="description" content={`Complete ERP solution for inventory management, billing, and business reporting for ${companyName}`} />
        <meta property="og:title" content={`${companyName} - Inventory, Billing & Reporting`} />
        <meta property="og:description" content={`Complete ERP solution for inventory management, billing, and business reporting for ${companyName}`} />
      </Helmet>
      
      <div className="flex h-screen bg-background text-foreground">
        <Sidebar activeModule={activeModule} setActiveModule={setActiveModule} />
        
        <main className="flex-1 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-auto">
            <motion.div
              key={activeModule}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.3 }}
              className="p-4 sm:p-6 lg:p-8 h-full"
            >
              {renderActiveModule()}
            </motion.div>
          </div>
        </main>
        
        <Toaster />
        <PDFViewport />
        {transactionToView && (
          <TransactionDetailView 
            transaction={transactionToView.transaction}
            type={transactionToView.type}
            onClose={() => setTransactionToView(null)}
          />
        )}
      </div>
    </>
  );
}


function App() {
  const { session, loading: authLoading } = useAuth();

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="text-2xl font-semibold text-foreground">Loading...</div>
      </div>
    );
  }

  return (
    <DataProvider>
      {session ? <AppContent /> : <Auth />}
    </DataProvider>
  );
}

export default App;
