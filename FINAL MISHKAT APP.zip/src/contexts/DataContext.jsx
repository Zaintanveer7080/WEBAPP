
import React, { createContext, useState, useContext, useEffect, useCallback } from 'react';
import * as bcrypt from 'bcryptjs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';

const DataContext = createContext();

export const useData = () => useContext(DataContext);

const getInitialState = () => {
    const initialState = {
      customers: [],
      suppliers: [],
      items: [],
      purchases: [],
      sales: [],
      expenses: [],
      banks: [],
      cashInHand: 0,
      cashTransactions: [],
      payments: [],
      onlineOrders: [],
      settings: {
        password: '',
        passcode: '',
        companyName: 'ERP Pro',
        companyLogo: ''
      }
    };
    try {
      const storedData = localStorage.getItem('erp_data');
      if (storedData) {
        const parsedData = JSON.parse(storedData);
        const mergedState = {
          ...initialState,
          ...parsedData,
          settings: {
            ...initialState.settings,
            ...(parsedData.settings || {}),
          },
        };
        return mergedState;
      }
      return initialState;
    } catch (error) {
      console.error("Error parsing localStorage data", error);
      return initialState;
    }
};


const PasscodeModal = ({ isOpen, onVerified, onClose }) => {
  const [enteredPasscode, setEnteredPasscode] = useState('');
  const { data } = useData();
  const { toast } = useToast();

  const handleVerify = (e) => {
    e.preventDefault();
    if (!data.settings.passcode) {
        toast({ title: "Info", description: "No passcode set. Action authorized." });
        onVerified();
        return;
    }
    if (bcrypt.compareSync(enteredPasscode, data.settings.passcode)) {
      toast({ title: "Success", description: "Action authorized." });
      onVerified();
    } else {
      toast({ title: "Error", description: "Incorrect passcode.", variant: "destructive" });
    }
    setEnteredPasscode('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Enter Passcode to Authorize</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleVerify} className="py-4 space-y-4">
          <div>
            <Label htmlFor="passcodeInput">Transaction Passcode</Label>
            <Input
              id="passcodeInput"
              type="password"
              value={enteredPasscode}
              onChange={(e) => setEnteredPasscode(e.target.value)}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Authorize</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};


export const DataProvider = ({ children }) => {
  const [data, setData] = useState(getInitialState);
  const [loading, setLoading] = useState(true);
  const [isPasscodeModalOpen, setIsPasscodeModalOpen] = useState(false);
  const [passcodeCallback, setPasscodeCallback] = useState(null);
  const [transactionToView, setTransactionToView] = useState(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const loadDataFromSupabase = useCallback(async () => {
    if (!user) {
      setData(getInitialState());
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data: appData, error } = await supabase
      .from('app_data')
      .select('data')
      .eq('user_id', user.id)
      .single();

    if (appData) {
        setData(appData.data);
    } else if (error && error.code !== 'PGRST116') {
        console.error('Error loading data from Supabase:', error);
        toast({ title: "Error", description: `Failed to load cloud data: ${error.message}`, variant: "destructive" });
        setData(getInitialState());
    } else {
        setData(getInitialState());
    }
    setLoading(false);
  }, [user, toast]);
  
  useEffect(() => {
    loadDataFromSupabase();
  }, [loadDataFromSupabase]);


  const updateData = useCallback(async (newData) => {
    const updatedData = { ...data, ...newData };
    setData(updatedData);
    localStorage.setItem('erp_data', JSON.stringify(updatedData));
    
    if (user) {
        const { error } = await supabase
            .from('app_data')
            .upsert({ user_id: user.id, data: updatedData, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
            
        if (error) {
            console.error('Error saving data to Supabase:', error);
            toast({ title: "Error", description: "Failed to save data to the cloud.", variant: "destructive" });
        }
    }
  }, [data, user, toast]);

  const requestPasscode = useCallback((onSuccess) => {
    if (data.settings?.passcode) {
      setPasscodeCallback(() => onSuccess);
      setIsPasscodeModalOpen(true);
    } else {
      onSuccess();
    }
  }, [data.settings?.passcode]);

  const onPasscodeVerified = () => {
    if (passcodeCallback) {
      passcodeCallback();
    }
    setIsPasscodeModalOpen(false);
    setPasscodeCallback(null);
  };

  const onPasscodeCancel = () => {
    setIsPasscodeModalOpen(false);
    setPasscodeCallback(null);
  }

  const getInvoiceStatus = useCallback((invoice, allPayments = data.payments) => {
    if (!invoice || !invoice.id) {
      return { status: 'Credit', paidAmount: 0, balance: invoice?.totalCost || 0 };
    }
    
    const totalPaidForInvoice = (allPayments || [])
      .filter(p => p && p.invoiceId === invoice.id)
      .reduce((sum, p) => sum + (p.amount || 0) + (p.discount || 0), 0);
    
    const totalCost = invoice.totalCost || 0;
    const balance = totalCost - totalPaidForInvoice;

    let status = 'Credit';
    if (balance <= 0.01) {
      status = 'Paid';
    } else if (totalPaidForInvoice > 0) {
      status = 'Partial';
    }

    return {
      status,
      paidAmount: totalPaidForInvoice,
      balance: balance > 0.01 ? balance : 0,
    };
  }, [data.payments]);

  const updateInvoicePaidAmount = useCallback((invoiceId, finalPaymentsList) => {
    let updatedSales = [...(data.sales || [])];
    let updatedPurchases = [...(data.purchases || [])];
  
    const saleIndex = updatedSales.findIndex(s => s.id === invoiceId);
    if (saleIndex > -1) {
      const originalSale = updatedSales[saleIndex];
      const { paidAmount } = getInvoiceStatus(originalSale, finalPaymentsList);
      updatedSales[saleIndex] = { ...originalSale, paidAmount };
    }
  
    const purchaseIndex = updatedPurchases.findIndex(p => p.id === invoiceId);
    if (purchaseIndex > -1) {
      const originalPurchase = updatedPurchases[purchaseIndex];
      const { paidAmount } = getInvoiceStatus(originalPurchase, finalPaymentsList);
      updatedPurchases[purchaseIndex] = { ...originalPurchase, paidAmount };
    }
    
    return { sales: updatedSales, purchases: updatedPurchases };
  }, [data.sales, data.purchases, getInvoiceStatus]);

  return (
    <DataContext.Provider value={{ data, updateData, requestPasscode, transactionToView, setTransactionToView, getInvoiceStatus, loading, updateInvoicePaidAmount }}>
      {children}
      {isPasscodeModalOpen && (
         <PasscodeModal
            isOpen={isPasscodeModalOpen}
            onVerified={onPasscodeVerified}
            onClose={onPasscodeCancel}
         />
      )}
    </DataContext.Provider>
  );
};
